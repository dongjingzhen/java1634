package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import po.Class;
import po.Paper;

import tools.HibernateSessionFactory;

public class ClassDao {
	public List<Class> AllClassList() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "from Class";
		Query querylist = session.createQuery(hql);
		List<Class> classlist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return classlist;
	}
	public List<String> AllClassName() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "select c.className from Class c";
		Query querylist = session.createQuery(hql);
		List<String> classNamelist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return classNamelist;
	}
	public List<Paper> testPrepare() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "select*from paper where className='G001' and state='准备开始' or state='考试中'";
		SQLQuery query = session.createSQLQuery(hql).addEntity(Paper.class);
		List<Paper> classNamelist = query.list();
		session.beginTransaction().commit();
		session.close();
		return classNamelist;
	}
}
