package action;

import java.util.List;

import po.Teacher;

import com.opensymphony.xwork2.Action;

import dao.TeacherDao;

public class TeacherAction implements Action {
    private List<Teacher> teachers;
	private Teacher teacher;
	public String teacher(){
		TeacherDao lecturer = new TeacherDao();
		teachers=lecturer.teachers();
		return "teacher";
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

}
