package action;

import java.util.List;

import po.Class;
import po.Paper;

import com.opensymphony.xwork2.Action;

import dao.ClassDao;

public class ClasssAction implements Action {
	private List<Class> allClass;
	private List<Paper> testPerpaer;

	public List<Class> getAllClass() {
		return allClass;
	}

	public void setAllClass(List<Class> allClass) {
		this.allClass = allClass;
	}

	public String allClass() {
		ClassDao clDao = new ClassDao();
		allClass = clDao.AllClassList();
		return "allClass";
	}

	public String testPerpaer() {
		ClassDao clDao = new ClassDao();
		testPerpaer = clDao.testPrepare();

		return "testPerpaer";
	}

	public List<Paper> getTestPerpaer() {
		return testPerpaer;
	}

	public void setTestPerpaer(List<Paper> testPerpaer) {
		this.testPerpaer = testPerpaer;
	}

	public String execute() throws Exception {

		return null;
	}

}
