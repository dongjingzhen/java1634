package com.jc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import com.jc.po.Paper;
import com.jc.po.Question;


public class QuestionDao {

	public  List<Question> list(){
		
Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction=session.beginTransaction();
		

	List<Question> questionList = session.createCriteria(Question.class).list();   
	for (Question question : questionList) {
		System.out.println(question);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return questionList;
	}

}
