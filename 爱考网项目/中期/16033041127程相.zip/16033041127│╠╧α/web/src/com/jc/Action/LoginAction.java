package com.jc.Action;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import sun.awt.AppContext;

import com.jc.dao.HibernateSessionFactory;
import com.jc.dao.TeacherDao;
import com.jc.dao.UserDao;
import com.jc.po.Teacher;
import com.jc.po.Users;
import com.opensymphony.xwork2.Action;

public class LoginAction implements Action {
	private String role;
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String login()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Users users=new Users();
		UserDao userDao=new UserDao();
		//�������ݿ��ѯ��¼
		System.out.println(role);
		boolean q;
		if (role=="teacher") {
			q=userDao.teacherList(users.getName(), users.getPaw());
		} 
		if (role=="student") {
			q=userDao.studentList(users.getName(), users.getPaw());
		}
		if (role=="admin") {
			q=userDao.adminList(users.getName(), users.getPaw());
		}
		if (q=true) {
			ServletActionContext.getRequest().getSession().setAttribute("name",users.getName() );
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "login";
		
	}
	
	

	public String execute() throws Exception {
		
		return null;
	}

}
