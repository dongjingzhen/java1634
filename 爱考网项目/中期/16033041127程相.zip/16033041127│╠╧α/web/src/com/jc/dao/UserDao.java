package com.jc.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.jc.po.Administrator;
import com.jc.po.Students;
import com.jc.po.Teacher;

public class UserDao {
	public boolean adminList(String aname,String apwd){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		boolean rel=false;
		Criteria criteria= session.createCriteria(Administrator.class).add(Restrictions.like("aname", aname)).add(Restrictions.like("apwd", apwd));
		List<Administrator> list= criteria.list();
		if (list.size()!=0) {
			rel=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return rel;
	}
	

	public boolean teacherList(String taccount,String tpwd){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		boolean rel=false;
		Criteria criteria= session.createCriteria(Teacher.class).add(Restrictions.like("taccount", taccount)).add(Restrictions.like("tpwd", tpwd));
		List<Teacher> list= criteria.list();
		if (list.size()!=0) {
			rel=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return rel;
	}
	public boolean studentList(String stuNo,String stuPwd){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		boolean rel=false;
		Criteria criteria= session.createCriteria(Students.class).add(Restrictions.like("stuNo", stuNo)).add(Restrictions.like("stuPwd", stuPwd));
		List<Students> list= criteria.list();
		if (list.size()!=0) {
			rel=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return rel;
	}

}
