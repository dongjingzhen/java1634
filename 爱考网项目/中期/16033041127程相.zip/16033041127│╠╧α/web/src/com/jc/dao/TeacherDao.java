package com.jc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jc.po.Teacher;


public class TeacherDao {

public List<Teacher> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
     for (Teacher teacher : teacherList) {
		System.out.println(teacher);
	}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}

}
