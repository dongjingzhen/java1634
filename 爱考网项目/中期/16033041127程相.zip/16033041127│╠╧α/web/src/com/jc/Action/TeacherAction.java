package com.jc.Action;

import java.util.List;

import com.jc.dao.TeacherDao;
import com.jc.po.Teacher;
import com.opensymphony.xwork2.Action;

public class TeacherAction implements Action {
	private List<Teacher> teacherList;

	public List<Teacher> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}
	public String list()
	{
		TeacherDao tdao = new TeacherDao();
		teacherList = tdao.list();
		System.out.println(teacherList.size());
		return "list";
	}
	




	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
