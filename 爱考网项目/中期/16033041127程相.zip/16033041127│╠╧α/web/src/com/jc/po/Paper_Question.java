package com.jc.po;
/**
 * �Ծ���Ŀ
 * @author Administrator
 *
 */
public class Paper_Question {
	private int pqid;
	private int pid;//�Ծ�id
	private int qid;//����id
	public int getPqid() {
		return pqid;
	}
	public void setPqid(int pqid) {
		this.pqid = pqid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	
	

}
