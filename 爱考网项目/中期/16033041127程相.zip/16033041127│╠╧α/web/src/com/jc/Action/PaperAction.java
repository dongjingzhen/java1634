package com.jc.Action;


import java.sql.Timestamp;
import java.util.List;

import com.jc.dao.PaperDao;
import com.jc.po.Paper;
import com.opensymphony.xwork2.Action;

public class PaperAction implements Action {
	private List<Paper> paperList;
	
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	public String paperList(){
		PaperDao paperDao=new PaperDao();
		paperList=paperDao.list();	
		return "pList";
	}
	public String createpaper(){
		PaperDao paperDao=new PaperDao(); 
		paperDao.list1(subjectName, kind, title, className,testHour, totalScore, qnumber, state, difficultyeasy, difficultycommonly,subjectselect);
		return "cater";
	}
	private Integer pid;
    private String subjectName;
    private String kind;
    private String title;
    private String className;
   
    private Integer testHour;
    private Double totalScore;
    private Integer qnumber;
    private String state;
    private int difficultyeasy;
    private int difficultycommonly;
    private String subjectselect;
    
	
	public String getSubjectselect() {
		return subjectselect;
	}
	public void setSubjectselect(String subjectselect) {
		this.subjectselect = subjectselect;
	}
	public int getDifficultyeasy() {
		return difficultyeasy;
	}
	public void setDifficultyeasy(int difficultyeasy) {
		this.difficultyeasy = difficultyeasy;
	}
	
	public int getDifficultycommonly() {
		return difficultycommonly;
	}
	public void setDifficultycommonly(int difficultycommonly) {
		this.difficultycommonly = difficultycommonly;
	}
	public Integer getTestHour() {
		return testHour;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}
	public Double getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(Double totalScore) {
		this.totalScore = totalScore;
	}
	public Integer getQnumber() {
		return qnumber;
	}
	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
