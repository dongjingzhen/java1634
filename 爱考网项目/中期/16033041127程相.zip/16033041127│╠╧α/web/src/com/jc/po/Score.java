package com.jc.po;

import java.util.Date;
/**
 * ���Գɼ�
 * @author Administrator
 *
 */
public class Score {
	private int id;
	private int classId;//�༶���ID
	private int stuId;//ѧ��ID
	private int subjectI;//��ĿID
	private int paperId;//�Ծ�ID
	private Date beginTime;//��ʼʱ��
	private Date endTime;//����ʱ��
	private float score;//�ɼ�
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public int getSubjectI() {
		return subjectI;
	}
	public void setSubjectI(int subjectI) {
		this.subjectI = subjectI;
	}
	public int getPaperId() {
		return paperId;
	}
	public void setPaperId(int paperId) {
		this.paperId = paperId;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	

}
