package com.jc.Action;

import java.util.List;

import com.jc.dao.QuestionDao;
import com.jc.dao.TeacherDao;
import com.jc.po.Paper;
import com.jc.po.Question;
import com.opensymphony.xwork2.Action;

public class QuestionAction implements Action {
	
	private List<Question> questionList;
	
	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public String questionList()
	{
		QuestionDao paperDao=new QuestionDao();
		questionList=paperDao.list();
		return "qList";
	}


	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
