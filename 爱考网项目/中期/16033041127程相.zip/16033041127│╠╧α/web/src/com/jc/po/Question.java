package com.jc.po;
// default package



/**
 * Question entity. @author MyEclipse Persistence Tools
 */

public class Question  implements java.io.Serializable {


    // Fields    

     @Override
	public String toString() {
		return "Question [answer=" + answer + ", chapter=" + chapter
				+ ", content=" + content + ", difficulty=" + difficulty
				+ ", kind=" + kind + ", optionA=" + optionA + ", optionB="
				+ optionB + ", optionC=" + optionC + ", optionD=" + optionD
				+ ", qid=" + qid + ", questionType=" + questionType
				+ ", subjectId=" + subjectId + "]";
	}

	private Integer qid;
     private String kind;
     private String content;
     private String optionA;
     private String optionB;
     private String optionC;
     private String optionD;
     private String answer;
     private String difficulty;
     private String subjectId;
     private String chapter;
     private String questionType;


    // Constructors

    /** default constructor */
    public Question() {
    }

    
    /** full constructor */
    public Question(String kind, String content, String optionA, String optionB, String optionC, String optionD, String answer, String difficulty, String subjectId, String chapter, String questionType) {
        this.kind = kind;
        this.content = content;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.answer = answer;
        this.difficulty = difficulty;
        this.subjectId = subjectId;
        this.chapter = chapter;
        this.questionType = questionType;
    }

   
    // Property accessors

    public Integer getQid() {
        return this.qid;
    }
    
    public void setQid(Integer qid) {
        this.qid = qid;
    }

    public String getKind() {
        return this.kind;
    }
    
    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getContent() {
        return this.content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }

    public String getOptionA() {
        return this.optionA;
    }
    
    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionB() {
        return this.optionB;
    }
    
    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public String getOptionC() {
        return this.optionC;
    }
    
    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getOptionD() {
        return this.optionD;
    }
    
    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public String getAnswer() {
        return this.answer;
    }
    
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getDifficulty() {
        return this.difficulty;
    }
    
    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getSubjectId() {
        return this.subjectId;
    }
    
    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

    public String getChapter() {
        return this.chapter;
    }
    
    public void setChapter(String chapter) {
        this.chapter = chapter;
    }

    public String getQuestionType() {
        return this.questionType;
    }
    
    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }
   








}