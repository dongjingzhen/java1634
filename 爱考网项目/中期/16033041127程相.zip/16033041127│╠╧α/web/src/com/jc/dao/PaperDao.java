package com.jc.dao;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jc.po.Paper;
import com.jc.po.Question;




public class PaperDao {
	private String title;
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Paper> list(){
		
        Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
	    List<Paper> paperList = session.createCriteria(Paper.class).list();   

		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return paperList;
	}
	public  List<Question> list1(String subjectName, String kind, String title, String className,
			Integer testHour, Double totalScore, Integer qnumber, String state,int difficultyeasy,int difficultycommonly,String subjectselect){
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction=session.beginTransaction();
		
		Paper paper = new Paper();
		paper.setSubjectName(subjectselect);
		paper.setKind(kind);
		paper.setTitle(title);//����
		paper.setTotalScore(totalScore);//�ܷ�
		paper.setTestHour(testHour);//����ʱ��
		paper.setQnumber(qnumber);//������
		paper.setState("׼������");
		
		
		
		String sql  ="select q.* from (select top " +
		difficultyeasy +
				"* from question where difficulty= '��'  order by newId() union select top " +
				difficultycommonly+
				"* from question where difficulty= '�е�' order by newId()) as q";
	
		//����obejct���� ���±�0����id��1������ѡ
		List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
		   
		for (Question question : questionList) {
			System.out.println(question);
			paper.getQset().add(question);
		}
		 
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return null;	
	}
	

	}