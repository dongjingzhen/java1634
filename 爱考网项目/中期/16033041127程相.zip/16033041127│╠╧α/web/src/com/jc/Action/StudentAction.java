package com.jc.Action;

import java.util.List;


import com.jc.dao.StudentDao;
import com.jc.po.Students;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action {
	private List<Students> StudentList;
	
	public List<Students> getStudentList() {
		return StudentList;
	}
	public void setStudentList(List<Students> studentList) {
		StudentList = studentList;
	}





	public String list()
	{
		StudentDao studentDao = new StudentDao();
		studentDao.list();
		return "list";
	}
	




	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
