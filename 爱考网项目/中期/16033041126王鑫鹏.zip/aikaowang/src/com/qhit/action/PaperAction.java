package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.PaperDao;
import com.qhit.domain.Paper;

public class PaperAction implements Action {
	private List<Paper> paperlist;
	private Paper paper;
	private int acount;
	private int bcount;
	

	public int getAcount() {
		return acount;
	}

	public void setAcount(int acount) {
		this.acount = acount;
	}

	public int getBcount() {
		return bcount;
	}

	public void setBcount(int bcount) {
		this.bcount = bcount;
	}

	public List<Paper> getPaperlist() {
		return paperlist;
	}

	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String selectpaper(){
		PaperDao paperDao=new PaperDao();
		paperlist=paperDao.selectpaper();
		System.out.println(paperlist.size());
		return "selectpaper";
	}
	public String savepaper(){
		
		PaperDao paperDao =new PaperDao();
		paperDao.savepaper(paper.getClassName(),acount,bcount,paper.getKind(),paper.getTitle(),paper.getSubjectName(),paper.getTestTime(), paper.getTestHour(),paper.getTotalScore());
		
		return "savepaper";	
		
	}

}
