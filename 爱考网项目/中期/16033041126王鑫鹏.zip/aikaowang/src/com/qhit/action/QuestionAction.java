package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.QuestionDao;
import com.qhit.domain.Question;
import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

public class QuestionAction implements Action {
	private Question question;
	private String subjectId;
   public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
   private List<Question> subjectlist;
   private List<Question> Ctblist;
	public List<Question> getCtblist() {
	return Ctblist;
}
public void setCtblist(List<Question> ctblist) {
	Ctblist = ctblist;
}
	public List<Question> getSubjectlist() {
	return subjectlist;
}
public void setSubjectlist(List<Question> subjectlist) {
	this.subjectlist = subjectlist;
}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
//	public String Qservlet(){
//		QuestionDao  questionDao=new  QuestionDao();
//		qlist=questionDao.list();
//		System.out.println(qlist.size());
//		return "Qservlet";
//	}
	
	public String Subjectsevlet(){
		QuestionDao questionDao=new QuestionDao();
		subjectlist=questionDao.slist();
		System.out.println(subjectlist.size());
		return "Subjectsevlet";
	}
	
	public String Ctblist(){
		System.out.println("a");
		System.out.println(subjectId);
		QuestionDao questionDao=new QuestionDao();
		Ctblist=questionDao.Ctblist(subjectId);
		
		System.out.println(Ctblist.toString());
		return "Ctblist";
	}

}
