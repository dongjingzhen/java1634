package com.qhit.action;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.LoginDao;
import com.qhit.domain.Admin;

public class UserAction implements Action{
	private int role;
	HttpSession se=ServletActionContext.getRequest().getSession();
	private Admin admin;


	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	private List<Admin> alist;
	
	
	public List<Admin> getAlist() {
		return alist;
	}

	public void setAlist(List<Admin> alist) {
		this.alist = alist;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String login()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Criteria criteria=session.createCriteria(Admin.class);
		//利用数据库查询登录
		alist=criteria.list();
		System.out.println(alist);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "login";
		
		
	}
//	public String login()
//	{
//	LoginDao loginDao =new LoginDao();
//	String as="";
//	if(getRole()==3){
//		//进入管理员判断
//
//		@SuppressWarnings("static-access")
//		boolean fan= loginDao.selectadmin(admin.getName(), admin.getPwd());
//		if (fan) {
//			se.setAttribute("admin", admin);
//			as= "index.jsp";
//		} else {
//			as="login";
//		}
//		return SUCCESS;
//		
//		
//		
//	}
//	return as;
//	
//	}	

}
