package com.qhit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;

import tools.HibernateSessionFactory;

import com.qhit.domain.Paper;
import com.qhit.domain.Question;
import com.sun.xml.internal.fastinfoset.sax.Properties;




public class QuestionDao {
	public static void main(String[] args) {
//        Session session = HibernateSessionFactory.getSession();
//		Transaction transaction=session.beginTransaction();
//		
//		Paper paper = new Paper();
//		paper.setTitle("java16班java考试");
//		String sql  ="select q.* from (select top" +
//				" 5 * from question where difficulty= " +
//				"'简单'  order by newId() " +
//				"union select top 5 *  " +
//				"from question where difficulty= " +
//				"'中等' order by newId()) as q";
//	
//	//返回obejct数组 ，下标0代表id，1代表单选
//	List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
//	   
//	for (Question question : questionList) {
//		System.out.println(question);
//		paper.getQset().add(question);
//	}
//	 
//		session.save(paper);
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
		//Qselect();
	}
	@SuppressWarnings("unchecked")
	public List<Question> list(){
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Criteria  criteria=session.createCriteria(Question.class);
		List<Question> qlist=criteria.list();
		for (Object object:qlist) {
			System.out.println(object);
		}
		transaction.commit();
		return qlist;
	}
	@SuppressWarnings("unchecked")
	public List<Question> slist(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql="select subjectId,count(subjectId) as count  " +
				"from question group by subjectId";
		List<Question> subjectlist=session.createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(Question.class)).list();
		for (Question question: subjectlist) {
			System.out.println(question.getSubjectId());
		}
		transaction.commit();
		return subjectlist;
		
	}
	
	public List<Question> Ctblist(String subjectId){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql="select *  " +
				"from question where subjectId like '"+subjectId+"' ";
		List<Question> Ctblist=session.createSQLQuery(sql).addEntity(Question.class).list();
		for (Question question: Ctblist) {
			System.out.println();
		}
		transaction.commit();
		return Ctblist;
		
	}
	
}


