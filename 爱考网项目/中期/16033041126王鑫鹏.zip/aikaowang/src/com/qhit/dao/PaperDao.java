package com.qhit.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.qhit.domain.Paper;
import com.qhit.domain.Question;

public class PaperDao {
	
	
	public List<Paper> selectpaper(){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql="select * from paper";
		List<Paper> paperlist=session.createSQLQuery(sql).addEntity(Paper.class).list();
		for (Paper paper : paperlist) {
			System.out.println(paper.toString());
		}
		return paperlist;
	}
	
	
	public void  savepaper(String subjectName,int acount,int bcount,String kind,String title,String className,Timestamp testTime,Integer testHour,Double totalScore)
	{
        Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Paper paper = new Paper();
		paper.setClassName(className);
		paper.setKind(kind);
		paper.setQnumber(acount+bcount);
		paper.setSubjectName(subjectName);
		paper.setTitle(title);
		paper.setTestTime(testTime);
		paper.setTestHour(testHour);
		paper.setTotalScore(totalScore);
		paper.setTitle("java16班java考试");
		String sql  ="select q.* from (select top" +
				" "+acount+" * from question where difficulty= " +
				"'简单'  order by newId() " +
				"union select top "+bcount+" *  " +
				"from question where difficulty= " +
				"'中等' order by newId()) as q";
	
	//返回obejct数组 ，下标0代表id，1代表单选
	List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
	   
	for (Question question : questionList) {
		System.out.println(question);
		paper.getQset().add(question);
	}
	 
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
}
