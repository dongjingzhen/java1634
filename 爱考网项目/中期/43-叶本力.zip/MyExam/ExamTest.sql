select * from admin

select * from class

select * from paper

select * from paper_question

select * from question

select * from score

select * from scoredetails

select * from student

select * from subject

select * from teacher

