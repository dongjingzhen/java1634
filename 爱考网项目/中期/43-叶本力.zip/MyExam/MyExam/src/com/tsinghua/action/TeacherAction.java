package com.tsinghua.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.TeacherDao;
import com.tsinghua.entity.Teacher;

public class TeacherAction implements Action {

	private List<Teacher> teacherList;

	public List<Teacher> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}

	
	public String list(){
		TeacherDao teacherDao = new TeacherDao();
		teacherList = teacherDao.getteacherlist();
		return SUCCESS;
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
