package com.tsinghua.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.tsinghua.entity.Paper;
import com.tsinghua.entity.Question;
import com.tsinghua.entity.Subject;
import com.tsinghua.tools.HibernateSessionFactory;

public class PaperDao {
	public List<Paper> getpaperlist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Paper> paperList = session.createCriteria(Paper.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperList;
	}

	public List<Question> getrodamquestion(String subject, String title,
			int testHour, double totalScore, int qnumber, String chapter,
			int difficultyeasy, int difficultycommonly, int difficultyhard,
			int duodifficultyeasy, int duodifficultycommonly,
			int duodifficultyhard) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper paper = new Paper();
		paper.setSubjectName(subject);
		paper.setTitle(title);
		paper.setTestHour(testHour);
		paper.setTotalScore(totalScore);
		paper.setQnumber(qnumber);

		String sql = "select * from (select top " + difficultyeasy
				+ " * from question " + "where difficulty = '简单' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '单选' " + "order by newID() "
				+ "union " + "select top " + difficultycommonly
				+ " * from question " + "where difficulty = '一般' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '单选' " + "order by newID() "
				+ "union " + "select top " + difficultyhard
				+ " * from question " + "where difficulty = '困难' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '单选' " + "order by newID() "
				+ "union    " + "select top " + duodifficultyeasy
				+ " * from question " + "where difficulty = '简单' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '多选' " + "order by newID() "
				+ "union " + "select top " + duodifficultycommonly
				+ " * from question " + "where difficulty = '一般' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '多选' " + "order by newID()"
				+ "union  " + "select top " + duodifficultyhard
				+ " * from question " + "where difficulty = '困难' "
				+ " and subjectId = '" + subject + "' and chapter = '"
				+ chapter + "' and kind = '多选' " + "order by newID())as q";
		SQLQuery query = session.createSQLQuery(sql).addEntity(Question.class);
		List<Question> list = query.list();
		Set<Question> setlist = new HashSet<Question>();
		setlist.addAll(list);

		paper.setQuestion(setlist);

		session.save(paper);

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return list;

	}

	public List<Question> getquestionsfrompaper() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		Paper paper = new Paper();
		paper = (Paper) session.get(Paper.class, 4);
		Set<Question> quelist = paper.getQuestion();
		List<Question> list = new ArrayList<Question>();
		list.addAll(quelist);

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	public List<Subject> getsubjectlist() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		String sql = "select * from  subject order by subjectid";

		SQLQuery query = session.createSQLQuery(sql).addEntity(Subject.class);
		List<Subject> typeList = query.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return typeList;

	}
}
