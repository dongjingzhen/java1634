package com.tsinghua.dao;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.tsinghua.entity.Admin;
import com.tsinghua.entity.Student;
import com.tsinghua.entity.Teacher;
import com.tsinghua.tools.HibernateSessionFactory;

public class LoginDao{
	public boolean login(String username,String pwd,String role){
		boolean a = false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		//利用数据库查询登录
		String name = null;
		if ("admin".equals(role)) {
			Criteria criteria = session.createCriteria(Admin.class);
			 criteria.add(Restrictions.like("aname",username ));
			 criteria.add(Restrictions.like("apwd",pwd ));
			if (criteria.list().size()!=0) {
				a = true;
				List<Admin> admin = criteria.list();
				for (Admin admin1 :admin ) {
					name = admin1.getAname();
				}
				ServletActionContext.getRequest().getSession().setAttribute("name", name);
			}
		}
		
		if ("student".equals(role)) {
			Criteria criteria = session.createCriteria(Student.class);
			 criteria.add(Restrictions.like("stuNo",username ));
			 criteria.add(Restrictions.like("stuPwd",pwd ));
			if (criteria.list().size()!=0) {
				a = true;
				List<Student> student = criteria.list();
				for (Student student2 : student) {
					name = student2.getStuName();
				}
				ServletActionContext.getRequest().getSession().setAttribute("name", name);
			}
		}
		
		if ("teacher".equals(role)) {
			Criteria criteria = session.createCriteria(Teacher.class);
			 criteria.add(Restrictions.like("taccount",username ));
			 criteria.add(Restrictions.like("tpwd",pwd ));
			if (criteria.list().size()!=0) {
				a = true;
				List<Teacher> teacher = criteria.list();
				for (Teacher teacher2 : teacher) {
					name = teacher2.getTname();
				}
				ServletActionContext.getRequest().getSession().setAttribute("name", name);
			}
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return a;
	}

}
