package com.tsinghua.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.tsinghua.entity.Teacher;
import com.tsinghua.tools.HibernateSessionFactory;

public class TeacherDao {

	public List<Teacher> getteacherlist()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}

}
