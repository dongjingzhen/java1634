package com.tsinghua.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.PaperDao;
import com.tsinghua.entity.Paper;
import com.tsinghua.entity.Question;
import com.tsinghua.entity.Subject;

public class PaperAction implements Action {
	private List<Paper> paperList;
	private List<Question> questionList;
	private Paper paper;
	private int difficultyeasy;
	private int difficultycommonly;
	private int difficultyhard;
	private int duodifficultyeasy;
	private int duodifficultycommonly;
	private int duodifficultyhard;
	private List<Subject> typeList;
	private String stage;

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public List<Subject> getTypeList() {
		return typeList;
	}

	public void setTypeList(List<Subject> typeList) {
		this.typeList = typeList;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public int getDifficultyeasy() {
		return difficultyeasy;
	}

	public void setDifficultyeasy(int difficultyeasy) {
		this.difficultyeasy = difficultyeasy;
	}

	public int getDifficultycommonly() {
		return difficultycommonly;
	}

	public void setDifficultycommonly(int difficultycommonly) {
		this.difficultycommonly = difficultycommonly;
	}

	public int getDifficultyhard() {
		return difficultyhard;
	}

	public void setDifficultyhard(int difficultyhard) {
		this.difficultyhard = difficultyhard;
	}

	public int getDuodifficultyeasy() {
		return duodifficultyeasy;
	}

	public void setDuodifficultyeasy(int duodifficultyeasy) {
		this.duodifficultyeasy = duodifficultyeasy;
	}

	public int getDuodifficultycommonly() {
		return duodifficultycommonly;
	}

	public void setDuodifficultycommonly(int duodifficultycommonly) {
		this.duodifficultycommonly = duodifficultycommonly;
	}

	public int getDuodifficultyhard() {
		return duodifficultyhard;
	}

	public void setDuodifficultyhard(int duodifficultyhard) {
		this.duodifficultyhard = duodifficultyhard;
	}

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	public String list() {
		PaperDao paperDao = new PaperDao();
		paperList = paperDao.getpaperlist();
		return SUCCESS;
	}

	public String rodampaper() {
		PaperDao paperDao = new PaperDao();
		questionList = paperDao.getrodamquestion(paper.getSubjectName(), paper.getTitle(), paper.getTestHour(),
				paper.getTotalScore(), paper.getQnumber(), stage, difficultyeasy,
				difficultycommonly, difficultyhard, duodifficultyeasy,
				duodifficultycommonly, duodifficultyhard);
		return SUCCESS;

	}

	public String getquestionsfrompaper() {
		PaperDao paperDao = new PaperDao();
		questionList = paperDao.getquestionsfrompaper();
		return SUCCESS;
	}

	public String getsubject() {

		PaperDao paperDao = new PaperDao();
		typeList = paperDao.getsubjectlist();

		return SUCCESS;

	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
