package com.tsinghua.entity;


// default package

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields

	private Integer id;
	private String direction;
	private String stage;
	private String subjectId;

	// Constructors

	/** default constructor */
	public Subject() {
	}
	
	/** full constructor */
	public Subject(Integer id, String direction, String stage, String subjectId) {
		this.id = id;
		this.direction = direction;
		this.stage = stage;
		this.subjectId = subjectId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

}