select * from paper
select * from question
insert into paper values('','','','','',1,100.0,1,'')


delete  from paper where pid = 3
select * from paper_question


 select
        * 
    from
        (select
            top 10 * 
        from
            question 
        where
            difficulty = '��'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID() 
        union
        select
            top 10 * 
        from
            question 
        where
            difficulty = 'һ��'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID() 
        union
        select
            top 5 * 
        from
            question 
        where
            difficulty = '����'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID() 
        union
        select
            top 10 * 
        from
            question 
        where
            difficulty = '��'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID() 
        union
        select
            top 10 * 
        from
            question 
        where
            difficulty = 'һ��'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID()
        union
        select
            top 5 * 
        from
            question 
        where
            difficulty = '����'  
            and subjectId = 'javascript' 
            and chapter = 'T02' 
            and kind = '��ѡ' 
        order by
            newID()
    )as q