package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Paper;
import po.PaperQuestion;
import po.Question;
import po.Subject;
import po.Classes;

public class PaperDao {

	//��ѯ���еİ༶
	public List<Classes> listClass(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Classes> classList = session.createCriteria(Classes.class).list();
		for (Classes class1 : classList) {
			System.out.println(class1);
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classList;
	}
	public List<Classes> listClass111(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Paper> paperList = session.createCriteria(Paper.class).list();
		List<Classes> classList = new ArrayList<Classes>();
		for (Paper paper : paperList) {
			classList.addAll(paper.getQclassName());
			for (Classes class1 : classList) {
				System.out.println(class1);
			}
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classList;
	}
	
	public List<Paper> list() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Paper> paperList = session.createCriteria(Paper.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperList;
	}

	public List<Subject> listType() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Subject> typeList = session.createCriteria(Subject.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return typeList;
	}

	public static String listQues(int pid) {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		Paper paper = (Paper) session.get(Paper.class, 1);
		List<Question> quelist = new ArrayList<Question>();
		quelist.addAll(paper.getQset());
		for (Question question : quelist) {
			System.out.println(question);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listQues";
	}

	public static void main(String[] args) {
		PaperDao dao = new PaperDao();
		dao.listClass();
	}

}
