package dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Admin;
import po.Student;
import po.Teacher;

public class LoginDao {

	//��ѯ����Ա�˺ź�����������֤�Ƿ���ȷ
	public String listAdmin(String name,String pwd){
		String admin ="";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		
		Criteria criteria = session.createCriteria(Admin.class).add(Restrictions.eq("aname", name))
				.add(Restrictions.eq("apwd", pwd));
		List<Admin> list =  criteria.list();
		if (list.size()!=0) {
			for (Admin admin2 : list) {
				admin = admin2.getAname();
				System.out.println(admin);
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return admin;
	}
	//��ѯѧ�����˺ź�����
	public String listStudent(String name,String pwd){
		String studentName = "";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		Criteria criteria = session.createCriteria(Student.class).add(Restrictions.eq("stuNo", name))
				.add(Restrictions.eq("stuPwd", pwd));
		List<Student> list =  criteria.list();
		if (list.size()!=0) {
			for (Student student : list) {
				studentName = student.getStuName();
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return studentName;
	}
	//��ѯ��ʦ���˺ź�����
	public String listTeacher(String name,String pwd){
		String teacherName = "";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		Criteria criteria = session.createCriteria(Teacher.class).add(Restrictions.eq("taccount", name))
				.add(Restrictions.eq("tpwd", pwd));
		List<Teacher> list =  criteria.list();
		if (list.size()!=0) {
			for (Teacher teacher : list) {
				teacherName = teacher.getTname();
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherName;
	}
	public static void main(String[] args) {
		LoginDao dao = new LoginDao();
		dao.listAdmin("adm", "123");
	}
}
