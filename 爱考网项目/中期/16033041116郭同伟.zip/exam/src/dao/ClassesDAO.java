package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Classes;


public class ClassesDAO {
	//��ѯ���еİ༶����һ��list���ϵ�action
	public List<Classes> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Classes> classesList = session.createCriteria(Classes.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classesList;
	}

}
