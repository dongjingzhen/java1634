package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Student;
import po.Teacher;


public class StudentDAO {
	
	public List<Student> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Student> studentList = session.createCriteria(Student.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return studentList;
	}

}
