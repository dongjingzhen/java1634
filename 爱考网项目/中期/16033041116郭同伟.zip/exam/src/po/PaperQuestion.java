package po;

/**
 * PaperQuestion entity. @author MyEclipse Persistence Tools
 */

public class PaperQuestion implements java.io.Serializable {

	// Fields

	private Integer pqid;
	private Integer pid;//�Ծ�id
	private Integer qid;//����id

	// Constructors

	/** default constructor */
	public PaperQuestion() {
	}

	/** full constructor */
	public PaperQuestion(Integer pid, Integer qid) {
		this.pid = pid;
		this.qid = qid;
	}

	// Property accessors

	public Integer getPqid() {
		return this.pqid;
	}

	public void setPqid(Integer pqid) {
		this.pqid = pqid;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Integer getQid() {
		return this.qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

}