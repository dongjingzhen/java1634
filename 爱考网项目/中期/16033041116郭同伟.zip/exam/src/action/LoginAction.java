package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.User;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;

import dao.HibernateSessionFactory;
import dao.LoginDao;

public class LoginAction implements Action {

	private User user;
	
	
	//��¼��֤
	public String listLogin(){
		LoginDao dao=new LoginDao();
		String jiaose = user.getRole();
		
		String name = "";
		if ("ѧ��".equals(jiaose)) {
			name = dao.listStudent(user.getName(), user.getPwd());
		}
        if ("��ʦ".equals(jiaose)) {
        	name = dao.listTeacher(user.getName(), user.getPwd());
		}
        if ("����Ա".equals(jiaose)) {
        	name = dao.listAdmin(user.getName(), user.getPwd());
        }
		if (!"".equals(name)) {
			ServletActionContext.getRequest().getSession().setAttribute("zhanghao", user.getName());
			ServletActionContext.getRequest().getSession().setAttribute("pagename", name);
			ServletActionContext.getRequest().getSession().setAttribute("role", jiaose);
			return "index";
		}
		return "login";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}



}
