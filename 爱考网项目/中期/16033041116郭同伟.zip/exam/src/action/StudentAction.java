package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Student;

import com.opensymphony.xwork2.Action;

import dao.StudentDAO;
import dao.TeacherDAO;


public class StudentAction implements Action {

	private List<Student> studentList;
	


	//��ѯ���е�ѧ��
	public String list()
	{
		StudentDAO tdao = new StudentDAO();
		studentList = tdao.list();
		System.out.println(studentList.size());
		return "list";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Student> getStudentList() {
		return studentList;
	}


	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

}
