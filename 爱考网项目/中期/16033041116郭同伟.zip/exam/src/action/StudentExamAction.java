package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Paper;
import po.Student;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class StudentExamAction implements Action {

	private String zhanghao;
	private List<Student> stuList;
	private List<Paper> listpaper = new ArrayList<Paper>();
	
	public String listShuxin(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println("-----------"+zhanghao);
		Criteria criteria= session.createCriteria(Student.class).add(Restrictions.eq("stuNo", zhanghao));
		stuList = criteria.list();
		for (Student student : stuList) {
			System.out.println(student.getStuName());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}
	public String listPaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println("-----------"+zhanghao);
		Criteria criteria= session.createCriteria(Student.class).add(Restrictions.eq("stuNo", zhanghao));
		stuList = criteria.list();
		for (Student student : stuList) {
			System.out.println(student.getSpaper());
			listpaper.addAll(student.getSpaper());
			for (Paper list : listpaper) {
				System.out.println(list.getTitle());
			}
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listpaper";
	}
	
	
	
	
	
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String getZhanghao() {
		return zhanghao;
	}
	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}
	public List<Student> getStuList() {
		return stuList;
	}
	public void setStuList(List<Student> stuList) {
		this.stuList = stuList;
	}

}
