package action;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Question;
import po.Subject;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.QuestionDao;

public class QuestionAction implements Action {

	private List<Object[]> typeList;
	private List<Subject> subjectList;
	private List<Question> quesList;
	private String subjectId;
	private String questionType;
	private Question question;
	private Integer qid;
	private String checkboxSelectAnswers[];
	private String radioSelectAnwsers;
	//��ѯ����
	public String listQuesType(){
		QuestionDao dao = new QuestionDao();
		typeList = dao.listSubject();
		
		return "listType";
	}
	//��ѯ����
	public String listQues(){
		QuestionDao dao = new QuestionDao();
		quesList = dao.listQues(subjectId,questionType);
		return "listQues";
	}
	//�޸�·����ѯ����
	public String getById(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		System.out.println("xiugaiID..."+qid);
		question = (Question) session.get(Question.class, qid);
		typeList = session.createCriteria(Subject.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "success";
	}
	//����·����ѯ����
	public String getByIdsave(){
		QuestionDao dao = new QuestionDao();
		subjectList = dao.listType();
		return "success";
	}
	//�޸�����
	public String update(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		StringBuffer answerBuffer = null;
		if("��ѡ".equals(question.getKind()) && checkboxSelectAnswers != null )
		{
 			answerBuffer = new StringBuffer();
 			for(String tempStr :checkboxSelectAnswers)
 			{
 				
 				answerBuffer.append(tempStr+",");
 			}
 			
 			String answer = answerBuffer.toString();
 			answer = answer.substring(0, answer.lastIndexOf(","));
 			question.setAnswer(answer);
		}
		if ("��ѡ".equals(question.getKind()) && radioSelectAnwsers!="") {
			question.setAnswer(radioSelectAnwsers);
		}
		System.out.println(qid);
        session.update(question);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "success";
	}
	//��������
	public String save(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();

		StringBuffer answerBuffer = null;
		if("��ѡ".equals(question.getKind()) && checkboxSelectAnswers != null )
		{
 			answerBuffer = new StringBuffer();
 			for(String tempStr :checkboxSelectAnswers)
 			{
 				
 				answerBuffer.append(tempStr+",");
 			}
 			
 			String answer = answerBuffer.toString();
 			answer = answer.substring(0, answer.lastIndexOf(","));
 			question.setAnswer(answer);
		}
		if ("��ѡ".equals(question.getKind()) && radioSelectAnwsers!="") {
			question.setAnswer(radioSelectAnwsers);
		}
	    session.save(question);
			
	    transaction.commit();
		HibernateSessionFactory.closeSession();
		return "success";
	}
	//ɾ������
	public String delete(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();

		System.out.println(qid);
		question = (Question) session.get(Question.class, qid);
		session.delete(question);
				
		transaction.commit();
	    HibernateSessionFactory.closeSession();
		return "success";
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	public List<Object[]> getTypeList() {
		return typeList;
	}
	public void setTypeList(List<Object[]> typeList) {
		this.typeList = typeList;
	}
	public List<Question> getQuesList() {
		return quesList;
	}
	public void setQuesList(List<Question> quesList) {
		this.quesList = quesList;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Integer getQid() {
		return qid;
	}
	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public String[] getCheckboxSelectAnswers() {
		return checkboxSelectAnswers;
	}
	public void setCheckboxSelectAnswers(String[] checkboxSelectAnswers) {
		this.checkboxSelectAnswers = checkboxSelectAnswers;
	}
	public String getRadioSelectAnwsers() {
		return radioSelectAnwsers;
	}
	public void setRadioSelectAnwsers(String radioSelectAnwsers) {
		this.radioSelectAnwsers = radioSelectAnwsers;
	}
	public List<Subject> getSubjectList() {
		return subjectList;
	}
	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

}
