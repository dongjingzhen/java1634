package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Classes;
import po.Student;

import com.opensymphony.xwork2.Action;

import dao.ClassesDAO;
import dao.StudentDAO;
import dao.TeacherDAO;


public class ClassesAction implements Action {

	private List<Classes> classesList;
	


	//��ѯ���еİ༶
	public String list()
	{
		ClassesDAO dao = new ClassesDAO();
		classesList = dao.list();
		System.out.println(classesList.size());
		return "list";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Classes> getClassesList() {
		return classesList;
	}


	public void setClassesList(List<Classes> classesList) {
		this.classesList = classesList;
	}

}
