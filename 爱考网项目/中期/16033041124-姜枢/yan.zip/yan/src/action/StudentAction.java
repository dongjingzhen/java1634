package action;

import java.util.List;


import po.Student;



import com.opensymphony.xwork2.Action;

import dao.StudentDao;





public class StudentAction implements Action {
    private List<Student> studnetList;
	
	public String studnetList(){
		StudentDao stDao = new StudentDao();
		studnetList=stDao.studnetList();
		return "studnetList";
	}
	
	public List<Student> getStudnetList() {
		return studnetList;
	}

	public void setStudnetList(List<Student> studnetList) {
		this.studnetList = studnetList;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
