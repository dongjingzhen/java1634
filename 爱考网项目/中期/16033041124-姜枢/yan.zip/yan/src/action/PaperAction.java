package action;

import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Paper;
import po.Question;
import po.Random;
import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

import dao.ClassDao;
import dao.PaperDao;

public class PaperAction implements Action {
    private List<Paper> paperlist;
    private Set<Question> questionSet;
    private List<String> allClassName;
   
    public List<String> getAllClassName() {
		return allClassName;
	}
	public void setAllClassName(List<String> allClassName) {
		this.allClassName = allClassName;
	}
	private int pid;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}
	private Paper paper;
    private Random random;
    public String random(){
	    Session session = HibernateSessionFactory.getSession();		
		Transaction transaction=session.beginTransaction();
		String sql  ="select q.* from (select top "
			+random.getDa()
			+" * from question where difficulty= '简单' and kind='单选' and subjectId='"
			+paper.getSubjectName()
			+"'  order by newId() union select top "
			+random.getDb()
			+" * from question where difficulty= '中等' and kind='单选' and subjectId='"
			+paper.getSubjectName()
			+"' order by newId() union select top "
			+random.getDc()
			+" * from question where difficulty= '困难' and kind='单选' and subjectId='"
			+paper.getSubjectName()
			+"' order by newId() union select top "
			+random.getDda()
			+" * from question where difficulty= '简单' and kind='多选' and subjectId='"
			+paper.getSubjectName()
			+"' order by newId() union select top "
			+random.getDdb()
			+" * from question where difficulty= '中等' and kind='多选' and subjectId='"
			+paper.getSubjectName()
			+"' order by newId() union select top "
			+random.getDdc()
			+" * from question where difficulty= '困难' and kind='多选' and subjectId='"
			+paper.getSubjectName()
			+"' order by newId()) as q";
		List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
		for (Question question : questionList) {
			System.out.println(question);
			paper.getQuestionset().add(question);
		}
	   System.out.println(questionList.size());
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
    	return "random";
    }
    
    public String allClassName(){
		ClassDao clDao = new ClassDao();
		allClassName=clDao.AllClassName();
		return "allClassName";
	}
    
    
    
	public String inio(){
		PaperDao dao = new PaperDao();
		paperlist =dao.pList();
		return "inio";
	}
	public String questionSet(){
		PaperDao dao = new PaperDao();
		questionSet =dao.questinSet(pid);
		return "questionSet";
	}
	public String stateSet(){
		PaperDao dao = new PaperDao();
		dao.stateSet(pid, paper);
		return "stateSet";
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public Random getRandom() {
		return random;
	}
	public void setRandom(Random random) {
		this.random = random;
	}

}
