package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Class;

import tools.HibernateSessionFactory;

public class ClassDao {
	//查询班级所有信息
	public List<Class> AllClassList() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "from Class";
		Query querylist = session.createQuery(hql);
		List<Class> classlist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return classlist;
	}
	//查询班级名称
	public List<String> AllClassName() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "select c.className from Class c";
		Query querylist = session.createQuery(hql);
		List<String> classNamelist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return classNamelist;
	}
}
