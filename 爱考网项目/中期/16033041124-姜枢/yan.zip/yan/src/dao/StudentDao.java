package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Student;

import tools.HibernateSessionFactory;

public class StudentDao {
	public List<Student> studnetList() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "from Student";
		Query querylist = session.createQuery(hql);
		List<Student> studentlist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return studentlist;
	}
}
