package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Teacher;

import com.opensymphony.xwork2.Action;

import dao.TeacherDAO;


public class TeacherAction implements Action {

	private List<Teacher> teacherList;
	
	public List<Teacher> getTeacherList() {
		return teacherList;
	}


	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}


	public String list()
	{
		TeacherDAO tdao = new TeacherDAO();
		teacherList = tdao.list();
		System.out.println(teacherList.size());
		return "list";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
