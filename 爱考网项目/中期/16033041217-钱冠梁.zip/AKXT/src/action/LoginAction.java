package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.User;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import dao.HibernateSessionFactory;
import dao.LoginDao;

public class LoginAction extends ActionSupport {

	private User user;
	
	public String listLogin(){
		LoginDao dao=new LoginDao();
		String jiaose = user.getRole();
		System.out.println(jiaose);
		
		boolean bb = false;
		if ("ѧ��".equals(jiaose)) {
			bb = dao.listStudent(user.getName(), user.getPwd());
			System.out.println(jiaose);
		}
        if ("��ʦ".equals(jiaose)) {
        	bb = dao.listTeacher(user.getName(), user.getPwd());
		}
        if ("����Ա".equals(jiaose)) {
        	bb = dao.listAdmin(user.getName(), user.getPwd());
        }
		if (bb) {
			System.out.println("�ɹ�����");
			ServletActionContext.getRequest().getSession().setAttribute("pagename", user.getName());
			ServletActionContext.getRequest().getSession().setAttribute("role", jiaose);
			return "index";
		}
		return "Login";
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}



}
