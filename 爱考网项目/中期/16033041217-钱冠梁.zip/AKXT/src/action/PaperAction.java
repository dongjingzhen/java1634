package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Paper;
import po.Paper_question;
import po.QuesType;
import po.Question;
import po.Subject;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.PaperDao;

public class PaperAction implements Action {

	private List<Paper> paperList;
	private List<Subject> typeList;
	private Paper paper;
	private QuesType quesType;
	private int pid;
	private List<Question> pqList = new ArrayList<Question>();
	
	public String listAllQues(){
		
		
		
		return "listAllQues";
	}
	
	public String listQues(){
		

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		System.out.println(pid);
		
		Paper paper = (Paper) session.get(Paper.class, pid);
		pqList.addAll(paper.getQset());
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listQues";
	}
	
	public String random(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql  ="select q.* from (select top " +quesType.getDanxuan1()+
				" * from question where difficulty= '��'  " +
				"order by newId() union select top " +quesType.getDanxuan2()+
				" *  from question where difficulty= '�е�' " +
				"order by newId() union select top " +quesType.getDanxuan3()+
				" *  from question where difficulty= '����' " +
				"order by newId()) as q where kind = '��ѡ'";
		String sql1  ="select q.* from (select top " +quesType.getDuoxuan1()+
				" * from question where difficulty= '��'  " +
				"order by newId() union select top " +quesType.getDuoxuan2()+
				" *  from question where difficulty= '�е�' " +
				"order by newId() union select top " +quesType.getDuoxuan3()+
				" *  from question where difficulty= '����' " +
				"order by newId()) as q where kind = '��ѡ'";
	List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
	List<Question> questionList1 = session.createSQLQuery(sql1).addEntity(Question.class).list();
	
	for (Question question : questionList) {
		System.out.println(question);
		paper.getQset().add(question);
	}
	 for (Question question : questionList1) {
		paper.getQset().add(question);
	}
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "success";
	}
	//��ѯ����
	public String listQuesType(){
		PaperDao dao = new PaperDao();
		typeList = dao.listType();
			
		return "listType";
	}
	
	
	public String list(){
		
		PaperDao dao = new PaperDao();
		paperList = dao.list();
		
		return "list";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Paper> getPaperList() {
		return paperList;
	}


	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public List<Subject> getTypeList() {
		return typeList;
	}
	public void setTypeList(List<Subject> typeList) {
		this.typeList = typeList;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public QuesType getQuesType() {
		return quesType;
	}
	public void setQuesType(QuesType quesType) {
		this.quesType = quesType;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public List<Question> getPqList() {
		return pqList;
	}

	public void setPqList(List<Question> pqList) {
		this.pqList = pqList;
	}


}
