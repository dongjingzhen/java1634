package po;

public class QuesType {

	private String danxuan1;
	private String danxuan2;
	private String danxuan3;
	
	private String duoxuan1;
	private String duoxuan2;
	private String duoxuan3;
	
	private int eachQuesScore;

	public String getDanxuan1() {
		return danxuan1;
	}

	public void setDanxuan1(String danxuan1) {
		this.danxuan1 = danxuan1;
	}

	public String getDanxuan2() {
		return danxuan2;
	}

	public void setDanxuan2(String danxuan2) {
		this.danxuan2 = danxuan2;
	}

	public String getDanxuan3() {
		return danxuan3;
	}

	public void setDanxuan3(String danxuan3) {
		this.danxuan3 = danxuan3;
	}

	public String getDuoxuan1() {
		return duoxuan1;
	}

	public void setDuoxuan1(String duoxuan1) {
		this.duoxuan1 = duoxuan1;
	}

	public String getDuoxuan2() {
		return duoxuan2;
	}

	public void setDuoxuan2(String duoxuan2) {
		this.duoxuan2 = duoxuan2;
	}

	public String getDuoxuan3() {
		return duoxuan3;
	}

	public void setDuoxuan3(String duoxuan3) {
		this.duoxuan3 = duoxuan3;
	}

	public int getEachQuesScore() {
		return eachQuesScore;
	}

	public void setEachQuesScore(int eachQuesScore) {
		this.eachQuesScore = eachQuesScore;
	}
	
	
	
}
