package po;


/**
 * Paper_question entity. @author MyEclipse Persistence Tools
 */

public class Paper_question  implements java.io.Serializable {


    // Fields    

     private Integer pqid;
     private Integer pid;
     private Integer qid;


    // Constructors

    /** default constructor */
    public Paper_question() {
    }

    
    /** full constructor */
    public Paper_question(Integer pid, Integer qid) {
        this.pid = pid;
        this.qid = qid;
    }

   
    // Property accessors

    public Integer getPqid() {
        return this.pqid;
    }
    
    public void setPqid(Integer pqid) {
        this.pqid = pqid;
    }

    public Integer getPid() {
        return this.pid;
    }
    
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getQid() {
        return this.qid;
    }
    
    public void setQid(Integer qid) {
        this.qid = qid;
    }
  
}