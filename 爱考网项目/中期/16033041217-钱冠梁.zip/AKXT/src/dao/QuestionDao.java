package dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Question;
import po.Subject;

public class QuestionDao {

	public List<Subject> listType(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Subject> typeList = session.createCriteria(Subject.class).list();
		for (Subject subject : typeList) {
			System.out.println(subject);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return typeList;
	}
	
	public List<Object[]> listSubject(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		String sql="select s.subjectId,q.questionType, count(qid) " +
				"from subject s left join question q on q.subjectId=s.subjectId " +
				"group by q.questionType,s.subjectId";
		
		List<Object[]> typeList = session.createSQLQuery(sql).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return typeList;
	}
	public List<Question> listQues(String subjectId,String questionType){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Criteria criteria =session.createCriteria(Question.class).add(Restrictions.eq("subjectId", subjectId)).add(Restrictions.eq("questionType", questionType));
		List<Question> quesList = criteria.list();
		System.out.println(subjectId+""+questionType);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return quesList;
	}
	public static void main(String[] args) {
		QuestionDao dao = new QuestionDao();
		List<Question> list = dao.listQues("CTB","");
		for (Question question : list) {
			System.out.println(question);
		}
	}
}
