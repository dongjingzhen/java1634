package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Paper;
import po.Paper_question;
import po.Question;
import po.Subject;

public class PaperDao {

	public List<Paper> list() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Paper> paperList = session.createCriteria(Paper.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperList;
	}

	public List<Subject> listType() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Subject> typeList = session.createCriteria(Subject.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return typeList;
	}

	// System.out.println(object2[0]+"11"+object2[1]+"22"+object2[2]+"33"+object2[3]+"44"+object2[4]+"55"+object2[5]+"66"+
	// object2[6]+"77"+object2[7]+"88"+object2[8]+"99"+object2[9]+"00"+object2[10]+"11"+object2[11]);
	public static String listQues(int pid) {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// String sql="select qid from paper_question where pid ="+pid;
		// List<Question> quesList=null;
		// List pq = session.createSQLQuery(sql).list();
		// for (Object object : pq) {
		// System.out.println(object);
		// Criteria criteria
		// =session.createCriteria(Question.class).add(Restrictions.eq("qid",
		// object));
		// List ques = criteria.list();
		// System.out.println(ques);
		// quesList = ques;
		// System.out.println(quesList);
		//			
		// }
		Paper paper = (Paper) session.get(Paper.class, 1);

		List<Question> quelist = new ArrayList<Question>();
		quelist.addAll(paper.getQset());

		for (Question question : quelist) {
			System.out.println(question);
		}

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listQues";
	}

	public static void main(String[] args) {
		listQues(1);
	}

}
