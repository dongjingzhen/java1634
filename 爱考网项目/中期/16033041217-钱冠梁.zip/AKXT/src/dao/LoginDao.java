package dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Amdin;
import po.Student;
import po.Teacher;

public class LoginDao {

	public boolean listAdmin(String name,String pwd){
		boolean b =false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		
		Criteria criteria = session.createCriteria(Amdin.class).add(Restrictions.eq("aname", name))
				.add(Restrictions.eq("apwd", pwd));
		List<Amdin> list =  criteria.list();
		if (list.size()!=0) {
			b = true;
			System.out.println(b);
		}
		System.out.println(b);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
	}
	public boolean listStudent(String name,String pwd){
		boolean b = false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		Criteria criteria = session.createCriteria(Student.class).add(Restrictions.eq("stuName", name))
				.add(Restrictions.eq("stuPwd", pwd));
		List<Student> list =  criteria.list();
		if (list.size()!=0) {
			b = true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
	}
	public boolean listTeacher(String name,String pwd){
		boolean b = false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(name+pwd);
		Criteria criteria = session.createCriteria(Teacher.class).add(Restrictions.eq("taccount", name))
				.add(Restrictions.eq("tpwd", pwd));
		List<Teacher> list =  criteria.list();
		if (list.size()!=0) {
			b = true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
	}
	public static void main(String[] args) {
		LoginDao dao = new LoginDao();
		dao.listAdmin("admin", "123");
	}
}
