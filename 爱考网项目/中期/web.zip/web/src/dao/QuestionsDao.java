package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Question;

import tools.HibernateSessionFactory;

public class QuestionsDao {
	
	    public List<Question> questionlist(){
	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();
	    String hql="select q from Question q";
	    Query querylist = session.createQuery(hql);
	    List<Question> questionslist=querylist.list();
	    session.beginTransaction().commit();
	    session.close();
	    	return questionslist;
	    
}
	    
	    public List<Object[]> questionlista(){
		    Session session =HibernateSessionFactory.getSession();
		    session.beginTransaction();
		    String sql="select count(qid) as a,subjectId from question group by subjectId";
		    Query querylist = session.createSQLQuery(sql);
		    List<Object[]> questionslist=querylist.list();
		    session.beginTransaction().commit();
		    session.close();
		    	return questionslist;
		    
	}

	    
	}
