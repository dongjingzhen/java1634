package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Teacher;

import com.opensymphony.xwork2.Action;
import tools.HibernateSessionFactory;

import dao.TeacherDao;

public class TeacherAction implements Action {
    private List<Teacher> teachers;
	private Teacher teacher;
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String teacher(){
		TeacherDao lecturer = new TeacherDao();
		teachers=lecturer.teachers();
		return "teacher";
	}
	
	public String deleteteacher() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();

        Teacher teacher=(Teacher) session.get(Teacher.class, id);
        System.out.println(teacher);
		session.delete(teacher);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return SUCCESS;
		
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

}
