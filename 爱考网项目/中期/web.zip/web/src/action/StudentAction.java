package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import po.Student;
import po.Teacher;
import tools.HibernateSessionFactory;



import com.opensymphony.xwork2.Action;

import dao.StudentDao;





public class StudentAction implements Action {
    private List<Student> studnetList;
    private Student student;
    private int id;
    
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String studnetList(){
		StudentDao stDao = new StudentDao();
		studnetList=stDao.studnetList();
		return "studnetList";
	}
	public String deletestudent() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();

		Student student=(Student) session.get(Student.class, id);
        System.out.println(student.getId());
		session.delete(student);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "shanchu";
		
	}
	public List<Student> getStudnetList() {
		return studnetList;
	}

	public void setStudnetList(List<Student> studnetList) {
		this.studnetList = studnetList;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
