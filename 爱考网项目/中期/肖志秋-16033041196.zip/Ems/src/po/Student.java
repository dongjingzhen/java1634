package po;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {
    //ѧ����
	// Fields

	private Integer id;
	private String stuNo;//ѧ��
	private String stuPwd;//����
	private String classId;//�༶id
	private String stuName;//ѧ������
	private String stuSex;//�Ա�
	private String stuTelphone;//��ϵ�绰
	private String parentPhone;//�ҳ��绰
	private String stuSchoolyear;//ѧ��
	private String stuId;//����֤
	private String stubrithday;//����
	private String stuProvide;//ʡ��
	private String stuMajor;//רҵ
	private String stuParent;//�ҳ�
	private String stuDrom;//����
	private String stuDromNo;//�����
	private String basicSituation;//�������
	private String educational;//��������
	private String guardian;//�໤�˹�ϵ
	private String address;//��ַ
	private String city;//����
	private String studyDirection;//�Ͷ�����
	private String image;//��Ƭ
	private String political;//������ò
    private Class classid;
    private Set<Paper> paperSet = new HashSet<Paper>();//���Ծ��Ķ�Զ�
	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String stuNo, String stuPwd, String classId, String stuName,
			String stuSex, String stuTelphone, String parentPhone,
			String stuSchoolyear, String stuId, String stubrithday,
			String stuProvide, String stuMajor, String stuParent,
			String stuDrom, String stuDromNo, String basicSituation,
			String educational, String guardian, String address, String city,
			String studyDirection, String image, String political) {
		this.stuNo = stuNo;
		this.stuPwd = stuPwd;
		this.classId = classId;
		this.stuName = stuName;
		this.stuSex = stuSex;
		this.stuTelphone = stuTelphone;
		this.parentPhone = parentPhone;
		this.stuSchoolyear = stuSchoolyear;
		this.stuId = stuId;
		this.stubrithday = stubrithday;
		this.stuProvide = stuProvide;
		this.stuMajor = stuMajor;
		this.stuParent = stuParent;
		this.stuDrom = stuDrom;
		this.stuDromNo = stuDromNo;
		this.basicSituation = basicSituation;
		this.educational = educational;
		this.guardian = guardian;
		this.address = address;
		this.city = city;
		this.studyDirection = studyDirection;
		this.image = image;
		this.political = political;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStuNo() {
		return this.stuNo;
	}

	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}

	public String getStuPwd() {
		return this.stuPwd;
	}

	public void setStuPwd(String stuPwd) {
		this.stuPwd = stuPwd;
	}

	public String getClassId() {
		return this.classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getStuName() {
		return this.stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuSex() {
		return this.stuSex;
	}

	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}

	public String getStuTelphone() {
		return this.stuTelphone;
	}

	public void setStuTelphone(String stuTelphone) {
		this.stuTelphone = stuTelphone;
	}

	public String getParentPhone() {
		return this.parentPhone;
	}

	public void setParentPhone(String parentPhone) {
		this.parentPhone = parentPhone;
	}

	public String getStuSchoolyear() {
		return this.stuSchoolyear;
	}

	public void setStuSchoolyear(String stuSchoolyear) {
		this.stuSchoolyear = stuSchoolyear;
	}

	public String getStuId() {
		return this.stuId;
	}

	public void setStuId(String stuId) {
		this.stuId = stuId;
	}

	public String getStubrithday() {
		return this.stubrithday;
	}

	public void setStubrithday(String stubrithday) {
		this.stubrithday = stubrithday;
	}

	public String getStuProvide() {
		return this.stuProvide;
	}

	public void setStuProvide(String stuProvide) {
		this.stuProvide = stuProvide;
	}

	public String getStuMajor() {
		return this.stuMajor;
	}

	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}

	public String getStuParent() {
		return this.stuParent;
	}

	public void setStuParent(String stuParent) {
		this.stuParent = stuParent;
	}

	public String getStuDrom() {
		return this.stuDrom;
	}

	public void setStuDrom(String stuDrom) {
		this.stuDrom = stuDrom;
	}

	public String getStuDromNo() {
		return this.stuDromNo;
	}

	public void setStuDromNo(String stuDromNo) {
		this.stuDromNo = stuDromNo;
	}

	public String getBasicSituation() {
		return this.basicSituation;
	}

	public void setBasicSituation(String basicSituation) {
		this.basicSituation = basicSituation;
	}

	public String getEducational() {
		return this.educational;
	}

	public void setEducational(String educational) {
		this.educational = educational;
	}

	public String getGuardian() {
		return this.guardian;
	}

	public void setGuardian(String guardian) {
		this.guardian = guardian;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStudyDirection() {
		return this.studyDirection;
	}

	public void setStudyDirection(String studyDirection) {
		this.studyDirection = studyDirection;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getPolitical() {
		return this.political;
	}

	public void setPolitical(String political) {
		this.political = political;
	}

	public Class getClassid() {
		return classid;
	}

	public void setClassid(Class classid) {
		this.classid = classid;
	}

	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

}