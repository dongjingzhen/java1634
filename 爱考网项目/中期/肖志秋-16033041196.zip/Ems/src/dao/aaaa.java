package dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Paper;
import po.Question;
import tools.HibernateSessionFactory;



public class aaaa {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		   Session session =HibernateSessionFactory.getSession();
		   session.beginTransaction();
		   Paper paper=(Paper) session.get(Paper.class, 1);
		   Set<Question> testpaper= paper.getQuestionset();
		 for (Question question : testpaper) {
			System.out.println(question.getKind());
		}
		
           session.beginTransaction().commit();
           session.close(); 
	}

}
