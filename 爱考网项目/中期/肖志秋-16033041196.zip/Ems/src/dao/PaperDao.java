package dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Paper;
import po.Question;
import tools.HibernateSessionFactory;

public class PaperDao {
     public List<Paper> pList(){
 	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();
        String hql="select p from Paper p";
       Query query =  session.createQuery(hql);
       List<Paper> papers = query.list();
	    session.beginTransaction().commit();
	    session.close();
    	 return papers;
     }
  
}
