package action;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import po.Paper;
import po.Student;
import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

import dao.PaperDao;


public class StudentExam implements Action {
	   private List<Paper> paperlist;//�Ծ��б�
	   private Student student; //ѧ������
	   private Paper paper;//�Ծ�����
	   
	//�鿴�Ծ�
	public String ioin(){
 	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();
	    String className= (String) ServletActionContext.getRequest().getSession().getAttribute("className");
	    System.out.println(className);
	    String sql ="select * from paper where className='"+className+"' and state='׼������' or state='������'";
	    Query query =  session.createSQLQuery(sql).addEntity(Paper.class);
	    paperlist=query.list();
	    session.beginTransaction().commit();
	    session.close();
		return "ioin";
	}
	
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Paper> getPaperlist() {
		return paperlist;
	}


	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Paper getPaper() {
		return paper;
	}


	public void setPaper(Paper paper) {
		this.paper = paper;
	}



}
