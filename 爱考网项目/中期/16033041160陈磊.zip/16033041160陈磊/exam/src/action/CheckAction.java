package action;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import po.Admin;
import po.User;
import tools.HibernateSessionFactory;
import com.opensymphony.xwork2.Action;

public class CheckAction implements Action {
    private User user;
    private Admin admin;
    private String role;
     
    public String logout(){
    	ServletActionContext.getRequest().getSession().invalidate();
    	return "logout";
    }
    
	public String check(){
	 Session session =	HibernateSessionFactory.getSession();
	 session.beginTransaction();
	 String r = "";
	 ServletActionContext.getRequest().getSession().setAttribute("username", user.getName());
	 //管理员登陆
	 if ("admin".equals(role)) {
		 String hql  = "select a from Admin a where a.aname='"+user.getName()+"' and a.apwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);		
		 if (admins.list().size() !=0) {			
			r = "check"; 
		}else{
			r="shib";
		}
	} 
	 //学生登录
	 if ("student".equals(role)) {
		 String hql  = "select s from Student s where s.stuNo='"+user.getName()+"' and s.stuPwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);		
		 if (admins.list().size() !=0) {
			r = "check"; 
		}else{
			r="shib";
		}
	} 
	 //教师登陆
	 if ("lecturer".equals(role)) {
		 String hql  = "select t from Teacher t where t.taccount='"+user.getName()+"' and t.tpwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);		
		 if (admins.list().size() !=0) {
			r = "check"; 
		}else{
			r="shib";
		}
	} 
	 session.beginTransaction().commit();
	 session.close();
		return r;
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

}
