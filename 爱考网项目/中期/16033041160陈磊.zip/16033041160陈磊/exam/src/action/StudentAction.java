package action;

import java.util.List;


import po.Student;



import com.opensymphony.xwork2.Action;

import dao.StudentDao;





public class StudentAction implements Action {
    private List<Student> studnetList;
    private List<Student> xstudnetList;
    
	public List<Student> getXstudnetList() {
		return xstudnetList;
	}

	public void setXstudnetList(List<Student> xstudnetList) {
		this.xstudnetList = xstudnetList;
	}

	public String studnetList(){
		StudentDao stDao = new StudentDao();
		studnetList=stDao.studnetList();
		return "studnetList";
	}
	
	public String xstudnetList(){
		StudentDao stDao = new StudentDao();
		xstudnetList=stDao.xstudnetList();
		return "xstudnetList";
	}
	
	
	public List<Student> getStudnetList() {
		return studnetList;
	}

	public void setStudnetList(List<Student> studnetList) {
		this.studnetList = studnetList;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
