package com.qhit.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.domain.Admin;

import tools.HibernateSessionFactory;
public class LoginDao {
	/**
	 * ��ѯ����Ա�˺ŵ�¼
	 * @param aname
	 * @param apwd
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static boolean  selectadmin(String aname,String apwd){
		boolean fan = false;
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		Query query=session.createQuery("from Admin ad where ad.aname ="+"'"+aname+"'"+" and ad.apwd ="+"'"+apwd+"'"+"");
		List<Admin> adminlist =query.list();
		if (adminlist.size()>0) {
			fan = true;
		}else {
			fan = false;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return fan;
		
	}
//	/**
//	 * ��ѯѧ���˺ŵ�¼
//	 * @param stuName
//	 * @param stuPwd
//	 * @return
//	 */
//	@SuppressWarnings("unchecked")
//	public static boolean  selectstudent(String stuName,String stuPwd){
//		boolean fan = false;
//		Session session=HibernateSessionFactory.getSession();
//		Transaction transaction= session.beginTransaction();
//		Query query=session.createQuery("from Student stu where stu.stuName ="+"'"+stuName+"'"+" and stu.stuPwd ="+"'"+stuPwd+"'"+"");
//		List<Student> studentlist =query.list();
//		if (studentlist.size()>0) {
//			fan = true;
//		}else {
//			fan = false;
//		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		return fan;
//		
//	}
//	/**
//	 * ��ѯ��ʦ�˺ŵ�¼
//	 * @param tname
//	 * @param tpwd
//	 * @return
//	 */
//	@SuppressWarnings("unchecked")
//	public static boolean  selectteacher(String tname,String tpwd){
//		boolean fan = false;
//		Session session=HibernateSessionFactory.getSession();
//		Transaction transaction= session.beginTransaction();
//		Query query=session.createQuery("from Teacher t where t.tname ="+"'"+tname+"'"+" and t.tpwd ="+"'"+tpwd+"'"+"");
//		List<Teacher> teacherlist =query.list();
//		if (teacherlist.size()>0) {
//			fan = true;
//		}else {
//			fan = false;
//		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		return fan;
//		
//	}
	

}
