package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.domain.Teacher;

import tools.HibernateSessionFactory;

public class TeacherDAO {
	
	public List<Teacher> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}

}
