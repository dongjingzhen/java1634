package com.tsinghua.entity;

import java.util.Date;

// default package

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Score implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer classId;
	private Integer stuId;
	private Integer subjectId;
	private Integer paperId;
	private Date beginTime;
	private Date endTime;
	private Double score;

	// Constructors

	/** default constructor */
	public Score() {
	}

	/** full constructor */
	public Score(Integer id, Integer classId, Integer stuId, Integer subjectId,
			Integer paperId, Date beginTime, Date endTime, Double score) {
		this.id = id;
		this.classId = classId;
		this.stuId = stuId;
		this.subjectId = subjectId;
		this.paperId = paperId;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.score = score;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getClassId() {
		return classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public Integer getStuId() {
		return stuId;
	}

	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}

	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public Integer getPaperId() {
		return paperId;
	}

	public void setPaperId(Integer paperId) {
		this.paperId = paperId;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

}