package com.tsinghua.entity;

import java.util.HashSet;
import java.util.Set;

// default package

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Teacher implements java.io.Serializable {

	// Fields

	private Integer id;
	private String taccount;
	private String tpwd;
	private String tname;
	private String tsex;
	private String tbirthday;
	private String teducation;
	private String ttelphone;
	private String tjop;
	private String remarks;
	private Set<Class> classes = new HashSet<Class>();

	// Constructors

	/** default constructor */
	public Teacher() {
	}

	/** full constructor */
	public Integer getId() {
		return id;
	}

	public Teacher(Integer id, String taccount, String tpwd, String tname,
			String tsex, String tbirthday, String teducation, String ttelphone,
			String tjop, String remarks, Set<Class> classes) {
		this.id = id;
		this.taccount = taccount;
		this.tpwd = tpwd;
		this.tname = tname;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.teducation = teducation;
		this.ttelphone = ttelphone;
		this.tjop = tjop;
		this.remarks = remarks;
		this.classes = classes;
	}

	public Set<Class> getClasses() {
		return classes;
	}

	public void setClasses(Set<Class> classes) {
		this.classes = classes;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTaccount() {
		return taccount;
	}

	public void setTaccount(String taccount) {
		this.taccount = taccount;
	}

	public String getTpwd() {
		return tpwd;
	}

	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTsex() {
		return tsex;
	}

	public void setTsex(String tsex) {
		this.tsex = tsex;
	}

	public String getTbirthday() {
		return tbirthday;
	}

	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}

	public String getTeducation() {
		return teducation;
	}

	public void setTeducation(String teducation) {
		this.teducation = teducation;
	}

	public String getTtelphone() {
		return ttelphone;
	}

	public void setTtelphone(String ttelphone) {
		this.ttelphone = ttelphone;
	}

	public String getTjop() {
		return tjop;
	}

	public void setTjop(String tjop) {
		this.tjop = tjop;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}