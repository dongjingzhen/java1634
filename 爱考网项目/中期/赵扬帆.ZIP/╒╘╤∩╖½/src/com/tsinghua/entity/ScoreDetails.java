package com.tsinghua.entity;

import java.util.Date;

// default package

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class ScoreDetails implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer scoreId;
	private Integer questionId;
	private String answer;
	private String result;

	// Constructors

	/** default constructor */
	public ScoreDetails() {
	}

	/** full constructor */
	public ScoreDetails(Integer id, Integer scoreId, Integer questionId,
			String answer, String result) {
		this.id = id;
		this.scoreId = scoreId;
		this.questionId = questionId;
		this.answer = answer;
		this.result = result;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getScoreId() {
		return scoreId;
	}

	public void setScoreId(Integer scoreId) {
		this.scoreId = scoreId;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}