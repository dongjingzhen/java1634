package com.tsinghua.dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.tsinghua.entity.Teacher;
import com.tsinghua.tools.HibernateSessionFactory;

public class TeacherDao {
     /**
      * 查询教师表
      * @return
      */
	public List<Teacher> getteacherlist()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
		for (Teacher teacher : teacherList) {
			System.out.println(teacher.getTname());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}
    /**
     * 删除教师表数据
     * @param id
     * @return
     */
    
//	public static int deleteteacher(int id){
//		
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		
//		Teacher teacher=(Teacher) session.get(Teacher.class, id);
//		
//		transaction.commit();
//		session.close();
//		return id;
//		
//		
//	}
	
//	public static void main(String[] args) {
//		deleteteacher(5);
//	}
}
