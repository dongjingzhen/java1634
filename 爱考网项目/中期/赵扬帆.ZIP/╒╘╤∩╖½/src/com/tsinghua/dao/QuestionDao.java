package com.tsinghua.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.tsinghua.entity.Question;
import com.tsinghua.tools.HibernateSessionFactory;

public class QuestionDao {
	public List<Question> getquestionlist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Question> teacherList = session.createCriteria(Question.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}
	public static void main(String[] args) {
		QuestionDao dao = new QuestionDao();
		dao.getquestionlist();
	}
}
