package com.tsinghua.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.tsinghua.entity.Paper;
import com.tsinghua.tools.HibernateSessionFactory;

public class PaperDao {
	
	/**
	 * 查询paper表的数据
	 * @return
	 */
	public List<Paper> getpaperlist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		List<Paper> paperList = session.createCriteria(Paper.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperList;
	}
	
	
	
	/**
	 * 随机组卷
	 *//*
	public void zujuanpaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Vector<Paper> vector = new Vector<Paper>();
		List<Paper> paperList = session.createCriteria(Paper.class).list();
		for (int i = 0; i <paperList.size() ; i++) {
			try {
				st=con.prepareStatement("select * from question where kind=? and chapter=? ");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/

}
