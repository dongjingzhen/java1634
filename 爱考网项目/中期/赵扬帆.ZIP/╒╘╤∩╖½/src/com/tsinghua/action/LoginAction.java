package com.tsinghua.action;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.LoginDao;

public class LoginAction implements Action {
	private String username;
	private String pwd;
	private String role;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String login() {
		LoginDao loginDao = new LoginDao();
		boolean judge = loginDao.login(username, pwd, role);
		if (judge == true) {
			return SUCCESS;
		} else {
			return ERROR;
		}

	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
