package com.tsinghua.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.TeacherDao;
import com.tsinghua.entity.Teacher;
import com.tsinghua.tools.HibernateSessionFactory;

public class TeacherAction implements Action {
    

	private List<Teacher> teacherList;
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
    
	public List<Teacher> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}

	//查询教师表
	public String list(){
		TeacherDao teacherDao = new TeacherDao();
		teacherList = teacherDao.getteacherlist();
		return SUCCESS;
	}
	//删除教师表数据
	public String deleteteacher() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();

Teacher teacher=(Teacher) session.get(Teacher.class, id);
System.out.println(teacher);
		session.delete(teacher);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return SUCCESS;
		
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
