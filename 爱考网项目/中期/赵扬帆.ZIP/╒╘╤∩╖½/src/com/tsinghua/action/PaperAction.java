package com.tsinghua.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.PaperDao;
import com.tsinghua.entity.Paper;

import com.tsinghua.tools.HibernateSessionFactory;

public class PaperAction implements Action {
	//查询paper表的数据
	private List<Paper> paperList;
	//paper表id
    private int pid;
    
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	//查询paper表的数据
	public String list() {
		PaperDao paperDao = new PaperDao();
		paperList = paperDao.getpaperlist();
		return SUCCESS;
	}
	
	public String deletepaper(){
	    Session session = HibernateSessionFactory.getSession();
	    Transaction transaction = session.beginTransaction();
	    
	    Paper paper = (Paper) session.get(Paper.class, pid);
	    
		session.delete(paper);
		transaction.commit();
		session.close();
		return SUCCESS;
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
