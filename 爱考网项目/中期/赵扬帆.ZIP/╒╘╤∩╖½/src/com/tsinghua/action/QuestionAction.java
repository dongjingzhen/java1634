package com.tsinghua.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.tsinghua.dao.QuestionDao;
import com.tsinghua.entity.Question;

public class QuestionAction implements Action {
	private List<Question> questionList;

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public String list() {
		QuestionDao questionDao = new QuestionDao();
		questionList = questionDao.getquestionlist();
		return SUCCESS;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
