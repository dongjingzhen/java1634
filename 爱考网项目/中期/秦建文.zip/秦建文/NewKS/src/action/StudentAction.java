package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import po.Student;
import tools.HibernateSessionFactory;



import com.opensymphony.xwork2.Action;

import dao.StudentDao;





public class StudentAction implements Action {
	private String  cout;
	



public String getCout() {
		return cout;
	}

	public void setCout(String cout) {
		this.cout = cout;
	}

private int id;

	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

	private List<Student> studnetList;
	
	public String studnetList(){
		StudentDao stDao = new StudentDao();
		studnetList=stDao.studnetList();
		return "studnetList";
	}
	
	public String student(){
		System.out.println("***************");
		Session  session=HibernateSessionFactory.getSession();
	  Transaction transaction=	session.beginTransaction();
		 cout= (String) session.get(Student.class,id);
		System.out.println(cout);
		transaction.commit();
		session.close();
		return "studnet";
	}
	
	
	public List<Student> getStudnetList() {
		return studnetList;
	}

	public void setStudnetList(List<Student> studnetList) {
		this.studnetList = studnetList;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
