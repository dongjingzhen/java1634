package action;

import java.util.List;

import po.Class;



import com.opensymphony.xwork2.Action;

import dao.ClassDao;



public class ClasssAction implements Action {
	//声明list，然后get，set
    private List<Class> allClass;
	
	

	public List<Class> getAllClass() {
		return allClass;
	}

	public void setAllClass(List<Class> allClass) {
		this.allClass = allClass;
	}

	public String allClass(){
		//声明并实例化dao方法
		ClassDao clDao = new ClassDao();
		//把查询到的数据给一个对象
		allClass=clDao.AllClassList();
		//返回这个对象到xml，然后返回到jsp，然后遍历输出
		return "allClass";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
