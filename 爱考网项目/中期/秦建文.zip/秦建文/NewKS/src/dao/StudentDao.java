package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Student;

import tools.HibernateSessionFactory;

public class StudentDao {
	public List<Student> studnetList() {
		//得到session
		Session session = HibernateSessionFactory.getSession();
		//开启事物
		session.beginTransaction();
		//创建一个查询学生信息的语句
		String hql = "from Student";
		//执行查询语句返回一个list集合
		Query querylist = session.createQuery(hql);
		//把查到的数据储存到list集合里面
		List<Student> studentlist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		//返回list
		return studentlist;
	}
}
