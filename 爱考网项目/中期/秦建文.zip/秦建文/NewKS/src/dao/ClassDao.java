package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Class;

import tools.HibernateSessionFactory;

public class ClassDao {
	public List<Class> AllClassList() {
		//得到session
		Session session = HibernateSessionFactory.getSession();
		//开启事物
		session.beginTransaction();
		//创建hql语句查询班级信息；
		String hql = "from Class";
		//执行查询语句返回一个list集合
		Query querylist = session.createQuery(hql);
		List<Class> classlist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		//返回list集合
		return classlist;
	}
	public List<String> AllClassName() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		//创建查询语句，查询班级的名字
		String hql = "select c.className from Class c";
		Query querylist = session.createQuery(hql);
		List<String> classNamelist = querylist.list();
		session.beginTransaction().commit();
		session.close();
		return classNamelist;
	}
}
