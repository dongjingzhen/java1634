package dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;

import po.Teacher;
import tools.HibernateSessionFactory;

public class TeacherDao {
    public List<Teacher> teachers(){
    Session session =HibernateSessionFactory.getSession();
    session.beginTransaction();
    //查询老师
    String hql="select t from Teacher t ";
    Query querylist = session.createQuery(hql);
    List<Teacher> teacherlist=querylist.list();
    session.beginTransaction().commit();
    session.close();
    	return teacherlist;
    }
    
}
