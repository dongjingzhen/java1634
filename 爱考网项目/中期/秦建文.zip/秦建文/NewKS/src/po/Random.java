package po;

public class Random {
	//��ѡ
  private int da;
  private int db;
  private int dc;
  //��ѡ
  private int dda;
  private int ddb;
  private int ddc;
public int getDa() {
	return da;
}
public void setDa(int da) {
	this.da = da;
}
public int getDb() {
	return db;
}
public void setDb(int db) {
	this.db = db;
}
public int getDc() {
	return dc;
}
public void setDc(int dc) {
	this.dc = dc;
}
public int getDda() {
	return dda;
}
public void setDda(int dda) {
	this.dda = dda;
}
public int getDdb() {
	return ddb;
}
public void setDdb(int ddb) {
	this.ddb = ddb;
}
public int getDdc() {
	return ddc;
}
public void setDdc(int ddc) {
	this.ddc = ddc;
}
   
}
