package po;

import java.util.HashSet;
import java.util.Set;

/**
 * 管理员信息
 * @author 19285
 *
 */
public class Adimin {
	//管理员id，主键，自增长
	private int adiminId;
	//管理员名字，即登录名
	private String adiminName;
	//管理员登录密码
	private String adiminPass;
	//与专业信息关联，一对多
	//private Set<Profession> professions = new HashSet<Profession>();
	//与科目信息关联，一对多
	//private Set<Subject> subjects = new  HashSet<Subject>();

//	public Set<Subject> getSubjects() {
//		return subjects;
//	}
//
//	public void setSubjects(Set<Subject> subjects) {
//		this.subjects = subjects;
//	}
//
//	public Set<Profession> getProfessions() {
//		return professions;
//	}
//
//	public void setProfessions(Set<Profession> professions) {
//		this.professions = professions;
//	}

	public int getAdiminId() {
		return adiminId;
	}

	public void setAdiminId(int adiminId) {
		this.adiminId = adiminId;
	}

	public String getAdiminName() {
		return adiminName;
	}

	public void setAdiminName(String adiminName) {
		this.adiminName = adiminName;
	}

	public String getAdiminPass() {
		return adiminPass;
	}

	public void setAdiminPass(String adiminPass) {
		this.adiminPass = adiminPass;
	}

}
