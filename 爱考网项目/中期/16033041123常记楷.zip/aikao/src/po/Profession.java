package po;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * 专业信息
 * @author 19285
 *
 */
public class Profession {
    //专业id，主键，自增长
	private int professionId;
	//专业名字，唯一，不为空
	private String professionName;
	//专业开设时间
	private Date professionOpen;
	//专业学习周期
	private int professionCycle;
	//专业创建负责人，与管理员关联，多对一
	private Adimin adimin;
	//与班级信息关联，一对多
	private Set<Classes> classes = new HashSet<Classes>();
	
	public int getProfessionId() {
		return professionId;
	}
	public void setProfessionId(int professionId) {
		this.professionId = professionId;
	}
	public Set<Classes> getClasses() {
		return classes;
	}
	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}
	public String getProfessionName() {
		return professionName;
	}
	public void setProfessionName(String professionName) {
		this.professionName = professionName;
	}
	public Date getProfessionOpen() {
		return professionOpen;
	}
	public void setProfessionOpen(Date professionOpen) {
		this.professionOpen = professionOpen;
	}
	public int getProfessionCycle() {
		return professionCycle;
	}
	public void setProfessionCycle(int professionCycle) {
		this.professionCycle = professionCycle;
	}
	public Adimin getAdimin() {
		return adimin;
	}
	public void setAdimin(Adimin adimin) {
		this.adimin = adimin;
	}
	
	
	
	
}
