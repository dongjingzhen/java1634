package po;

import java.util.HashSet;
import java.util.Set;
/**
 * ������Ϣ
 * @author 19285
 *
 */
public class Papers {
    //试卷id
	private int papersId;
    //试卷名字
	private String  papersName;
    //出卷人
	private String  papersPeople;
    //总分
	private int totalScore;
    //总题数
	private int totalCount;
	//哪个科目
	private int  papersSubjectId;
	//试卷类型
	private String  papersType;
	//但题分数
	private int oneTopicScore;
	
	
	private Set<Topic> topics = new HashSet<Topic>();
	


	public int getOneTopicScore() {
		return oneTopicScore;
	}
	public void setOneTopicScore(int oneTopicScore) {
		this.oneTopicScore = oneTopicScore;
	}
	public int getPapersId() {
		return papersId;
	}
	public void setPapersId(int papersId) {
		this.papersId = papersId;
	}

	public String getPapersName() {
		return papersName;
	}
	public void setPapersName(String papersName) {
		this.papersName = papersName;
	}
	public String getPapersPeople() {
		return papersPeople;
	}
	public void setPapersPeople(String papersPeople) {
		this.papersPeople = papersPeople;
	}
	public int getPapersSubjectId() {
		return papersSubjectId;
	}
	public void setPapersSubjectId(int papersSubjectId) {
		this.papersSubjectId = papersSubjectId;
	}
	public String getPapersType() {
		return papersType;
	}
	public void setPapersType(String papersType) {
		this.papersType = papersType;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public Set<Topic> getTopics() {
		return topics;
	}
	public void setTopics(Set<Topic> topics) {
		this.topics = topics;
	}

}
