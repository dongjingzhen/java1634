package action;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import po.User;

import com.opensymphony.xwork2.Action;

import dao.LoginDao;

public class LoginAction implements Action {
	// 角色类，接受前台传回的登陆数据，并判断用户角色
	private User user;
	
	private LoginDao loginDao;

	public LoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(LoginDao loginDao) {
		this.loginDao = loginDao;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String someOneLogin() {
		
		  //得到session对象
		  HttpSession session = ServletActionContext.getRequest().getSession();
		  
		  //将list集合放到session对象中方便前台使用el表达式操作
		 
		
		String message = loginDao.toLogin(user);
		
		
		session.setAttribute("user", user);
		System.out.println(user.getName());
		System.out.println(user.getPwd());
		System.out.println(user.getTrueName());
	    System.out.println(message);
		
		return message;
	}

}
