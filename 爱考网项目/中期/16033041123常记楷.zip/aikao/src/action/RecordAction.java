package action;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import po.Classes;
import po.Papers;
import po.Record;

import com.opensymphony.xwork2.Action;

import dao.RecordDao;

public class RecordAction implements Action {
	// 实例化recorddao类
	RecordDao recordDao = new RecordDao();
	// 实例化precord类
	private Record record;
	// 实例化papers类
	private Papers papers;
	// 声明classes类集合
	private List<Classes> classes;
	// 声明records类集合
	private List<Record> records;

	public List<Record> getRecords() {
		return records;
	}

	public void setRecords(List<Record> records) {
		this.records = records;
	}

	public List<Classes> getClasses() {
		return classes;
	}

	public void setClasses(List<Classes> classes) {
		this.classes = classes;
	}

	public Papers getPapers() {
		return papers;
	}

	public void setPapers(Papers papers) {
		this.papers = papers;
	}

	public Record getRecord() {
		return record;
	}

	public void setRecord(Record record) {
		this.record = record;
	}

	@Override
	public String execute() throws Exception {

		return null;
	}

	/**
	 * 添加考试记录
	 * 
	 * @return
	 */
	public String addRecord() {

		// 调用recorddao方法并传值
		recordDao.addRecord(record);

		// 返回值
		return "addok";

	}

	/**
	 * 查询某张试卷的信息
	 * 
	 * @return
	 */
	public String getonePapers() {

		// 调用recorddao方法传参并接受返回值
		papers = recordDao.getonePapers(papers);
		// 调用recorddao方法接受返回值
		classes = recordDao.getallClasses();
		// 返回值
		return "getone";

	}

	/**
	 * 查询所有的考试记录
	 * 
	 * @return
	 */
	public String getAllRecord() {
		// 调用recorddao方法接受返回值
		records = recordDao.getAllRecord();
		// 返回值
		return "getallok";
	}

}
