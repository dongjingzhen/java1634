package dao;

import java.util.List;

import org.hibernate.Session;

import po.Student;
import po.User;

public class LoginDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	public static String toLogin(User user) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		System.out.println(user.getRole());
		System.out.println(user.getName());
		System.out.println(user.getPwd());

		String message = "notlogin";

		// 1学生，2老师，4管理员
		if ("1".equals(user.getRole())) {

			String sql = "select * from tb_student where studentNumber='"
					+ user.getName() + "' and studentPass='" + user.getPwd()
					+ "'";
			 List<Object[]> list = session.createSQLQuery(sql).list();
			
			if (list.size() != 0) {
				
			for (Object[] objects : list) {
			 user.setTrueName(objects[1].toString());	
			}

				message = "islogin";
			}

		}
		if ("2".equals(user.getRole())) {

			String sql = "select * from tb_teacher where teacherNumber='"
					+ user.getName() + "' and teacherPass='" + user.getPwd()
					+ "'";
			if (session.createSQLQuery(sql).list().size() != 0) {

				message = "islogin";
			}

		}
		if ("4".equals(user.getRole())) {

			String sql = "select * from tb_adimin where adiminNumber='"
					+ user.getName() + "' and adiminPass='" + user.getPwd()
					+ "'";
			if (session.createSQLQuery(sql).list().size() != 0) {

				message = "islogin";
			}

		}

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		return message;
	}

}
