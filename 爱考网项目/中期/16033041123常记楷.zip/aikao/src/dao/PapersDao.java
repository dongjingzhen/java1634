package dao;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.ManyofTopic;
import po.Papers;
import po.Subject;
import po.Topic;

public class PapersDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		getOnePapersTopic((Papers) session.get(Papers.class, 6));

	}

	/**
	 * 添加试卷
	 * 
	 * @param papers
	 * @param manyofTopic
	 */
	public static void addPapers(Papers papers, ManyofTopic manyofTopic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		// 创建sql查询语句，实现随机选题
		String sql = "select t.* from(" +

		" select top "
				+ manyofTopic.getOnejd()
				+ "* from tb_topic where topicDifficulty='简单'  and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=1 order by newId() union "
				+

				" select top "
				+ manyofTopic.getOneyb()
				+ "* from tb_topic where topicDifficulty='一般' and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=1 order by newId() union "
				+

				" select top "
				+ manyofTopic.getOnekn()
				+ " * from tb_topic where topicDifficulty='困难' and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=1 order by newId() union "
				+

				" select top "
				+ manyofTopic.getManyjd()
				+ " * from tb_topic where topicDifficulty='简单' and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=2 order by newId() union "
				+

				" select top "
				+ manyofTopic.getManyyb()
				+ " * from tb_topic where topicDifficulty='一般' and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=2 order by newId() union "
				+

				" select top "
				+ manyofTopic.getManykn()
				+ " * from tb_topic where topicDifficulty='困难' and topicType='笔试'  and subjectId="
				+ papers.getPapersSubjectId()
				+ " and topicSelect=2 order by newId()" +

				") as t";
		// 使用object数组接受查询结果集
		List<Object[]> topics = session.createSQLQuery(sql).list();
		papers.setPapersSubjectId(papers.getPapersSubjectId());
		// 保存试卷类
		session.save(papers);
		// 使用for循环让试题与试卷关联
		for (Object[] objects : topics) {
			Topic aa = (Topic) session.get(Topic.class,
					(Serializable) objects[0]);
			Papers papers2 = (Papers) session.get(Papers.class,
					papers.getPapersId());
			papers2.getTopics().add(aa);
		}

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();

	}

	/**
	 * 查询所有的考卷信息
	 * 
	 * @return
	 */
	public List<Papers> getAllPapers() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 用papers类集合接收查询结果集
		List<Papers> list = session.createCriteria(Papers.class).list();

		// 提交事务，关闭session
		transaction.commit();
		session.close();
		// 返回查询结果
		return list;

	}

	/**
	 * 查询某张考卷的全部题目
	 * 
	 * @param papers
	 * @return
	 */
	public static List<Object[]> getOnePapersTopic(Papers papers) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		// 创建sql查询语句
		String sql = "select * from tb_topic where topicId in(select topicId from top_pap where papersId="
				+ papers.getPapersId() + ")";
		// 执行sql语句，并用object数组接收结果集
		List<Object[]> list = session.createSQLQuery(sql).list();

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		// 返回查询结果
		return list;

	}

}
