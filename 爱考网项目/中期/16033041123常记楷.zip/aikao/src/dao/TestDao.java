package dao;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Adimin;
import po.Classes;
import po.Papers;
import po.Profession;
import po.Record;
import po.Student;
import po.Subject;
import po.Teacher;
import po.Topic;

public class TestDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		getAllRecord();
		//addTopic();
	
//		String me="";
//		
//		
//		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		
//		
//		try {
//			Date dt1 = format.parse("1999-01-01 12:20:49");
//			Date dt2 = format.parse("1999-01-01 12:20:50");
//			
//			if(dt1.getTime()>dt2.getTime()){
//				
//				System.out.println("1>2");
//				me="1>2";
//				
//			}else 	if(dt1.getTime()<=dt2.getTime()-1000*60*15){
//				System.out.println(dt2.getTime());
//				System.out.println(dt1.getTime());
//				System.out.println("1<2");
//				me="1<2";
//				
//			}
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//		
//		System.out.println(me);
		
		
		
	}
	
	public static List<Record> getAllRecord() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		List<Record> records2 = new ArrayList<Record>();



		String sql = "select className from tb_class where classId=(select classId from tb_student where studentNumber='S1602007')";
		String a0=session.createSQLQuery(sql).list().toString();
		a0=a0.substring(a0.indexOf("[")+1, a0.lastIndexOf("]"));
        System.out.println(a0);
        
        String[] aaa = null;
        
		String hql="select r from Record r where r.papersStatus = '考试结束'";
		
		Query query = session.createQuery(hql);
		
		List<Record> records = query.list();
		for (Record record : records) {
			String[] a1 = record.getClassId().split(",");
			for (int i = 0; i < a1.length; i++) {
				if(a0.equals(a1[i].trim())){
					System.out.println(a1[i].trim());
					System.out.println(a0);
					System.out.println(record.getRecordId());
					
					Record record2=(Record) session.get(Record.class,record.getRecordId()); 
					records2.add(record2);
				}
			}
			
		}
		
		
        System.out.println(records2.size());
        for (Record record : records2) {
			
			System.out.println(record.getPapersId());
		}
		

//		List<Object[]> objects =  session.createSQLQuery(sql1).list();
//		  for (Object[] objects2 : objects) {
//			
//			String a1 = objects2[1].toString();
//			String[] a2=a1.split(",");
//		    for (int i = 0; i < a1.split(",").length; i++) {
//				if(a0.equals(a2[i].trim())){
//					System.out.println("if里面"+a2[i].trim());
//					System.out.println("if里面"+a0);
//					System.out.println(objects2[0]);
//					Record record = (Record) session.get(Record.class, (Serializable) objects2[0]);
//					System.out.println(record.getPapersStatus());
//					
//					
//                    aaa=(String[]) objects2[0];
//					
//					
//				}
//		    	
//		    	
//			}
//		  
//		  
//		  }
//		  System.out.println(aaa.length);

        
		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		// 返回查询结果
		return null;
	}

}
