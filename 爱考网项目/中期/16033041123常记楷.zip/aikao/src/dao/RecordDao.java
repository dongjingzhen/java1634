package dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import po.Classes;
import po.Papers;
import po.Record;

public class RecordDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		getallClasses();

	}

	/**
	 * 添加考试记录
	 * 
	 * @param record
	 */
	public static void addRecord(Record record) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		String rstaus = "";

		Date now = new Date();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date dt1;
		Date dt2;
		Date dt3;
		try {
			dt1 = format.parse(record.getStartTime().toString());
			dt2 = format.parse(record.getEndTime().toString());
			dt3 = format.parse(format.format(now).toString());

			if (dt1.getTime() <= dt3.getTime()) {

				rstaus = "正在考试";
				if (dt2.getTime() < dt3.getTime()) {
					rstaus = "考试结束";

				}

			} else {

				rstaus = "未开考";
			}
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		record.setPapersStatus(rstaus);

		// 保存传回的record对象
		session.save(record);

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();

	}

	/**
	 * 查询所有的考试记录
	 * 
	 * @return
	 */
	public static List<Record> getAllRecord() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String rstaus = "";
		// 用record类集合接收查询结果集
		List<Record> list = session.createCriteria(Record.class).list();

		for (Record record : list) {

			Date now = new Date();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			Date dt1;
			Date dt2;
			Date dt3;
			try {
				dt1 = format.parse(record.getStartTime().toString());
				dt2 = format.parse(record.getEndTime().toString());
				dt3 = format.parse(format.format(now).toString());

				if (dt1.getTime() <= dt3.getTime()) {

					rstaus = "正在考试";
					if (dt2.getTime() < dt3.getTime()) {
						rstaus = "考试结束";

					}

				} else {

					rstaus = "未开考";
				}

				record.setPapersStatus(rstaus);
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		// 返回查询结果
		return list;
	}

	/**
	 * 查询某张试卷的信息
	 * 
	 * @param papers
	 * @return
	 */
	public Papers getonePapers(Papers papers) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		// 用papers类对象接受查询结果
		Papers papers2 = (Papers) session.get(Papers.class,
				papers.getPapersId());

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		// 返回查询结果
		return papers2;

	}

	/**
	 * 查询所有班级
	 * 
	 * @return
	 */
	public static List<Classes> getallClasses() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();

		// 用classes类集合接收查询到的结果集
		List<Classes> list = session.createCriteria(Classes.class).list();
		// ArrayList arrayList = new ArrayList();
		// String[] ars = null;
		// List<Record> records = getAllRecord();
		//
		// List<Classes> list = session.createCriteria(Classes.class).list();
		//
		// for (Record record : records) {
		//
		// ars = record.getClassId().split(",");
		//
		// }
		//
		//
		// for (int i = 0; i <ars.length; i++) {
		//
		// System.out.println("1111111"+list.get(i).getClassName());
		// arrayList.add(list.get(i).getClassName());
		// System.out.println("2222222"+ars[i]);
		// if(list.get(i).getClassName().equals(ars[i]))
		// list.remove(i);
		// }
		//
		// for (int i = 0; i < arrayList.size(); i++) {
		// System.out.println("6666666"+arrayList.get(i));
		// }
		// list=arrayList;

		// 提交事务，关闭session
		session.beginTransaction().commit();
		session.close();
		// 返回查询结果
		return list;

	}

}
