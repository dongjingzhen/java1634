package action;

import java.util.List;

import po.Paper;
import po.Question;

import com.opensymphony.xwork2.Action;

import dao.AdminDao;
import dao.StudentDao;

public class StudentAction implements Action {

	AdminDao adao=new AdminDao();
	StudentDao dao= new StudentDao();
	private List<Question> qlist;
	private List<Paper> plist;
	private int id;
	private int qid;
	
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public List<Question> getQlist() {
		return qlist;
	}
	public void setQlist(List<Question> qlist) {
		this.qlist = qlist;
	}
	public List<Paper> getPlist() {
		return plist;
	}
	public void setPlist(List<Paper> plist) {
		this.plist = plist;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String sepaper(){
		plist=dao.paperlist();
		return "sepaper";
	}
	public String exam(){
        qlist=adao.seque(id);
		return "exam";
	}
	public String qexam(){
		qlist=dao.qlist(qid);
		return "qexam";
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
