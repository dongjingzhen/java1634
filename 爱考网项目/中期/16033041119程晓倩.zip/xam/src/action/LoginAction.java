package action;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import po.Admin;

import com.opensymphony.xwork2.Action;

import dao.LoginDao;

public class LoginAction implements Action {
	private int role;
	private Admin admin;
	//HttpSession se=ServletActionContext.getRequest().getSession();
	HttpSession se=ServletActionContext.getRequest().getSession();
	public String login(){
		LoginDao loginDao=new LoginDao();
		String as="";
		if (getRole()==1) {
			//����ѧ���ж�
			@SuppressWarnings("static-access")
			boolean fan= loginDao.selectstudent(admin.getAname(), admin.getApwd());
			if (fan) {
				se.setAttribute("admin", admin);
				as= "index.jsp";
			} else {
				as="login";
			}
			return as;	
		}else if(getRole()==2){
			//������ʦ�ж�
			@SuppressWarnings("static-access")
			boolean fan= loginDao.selectteacher(admin.getAname(), admin.getApwd());
			if (fan) {
				se.setAttribute("admin", admin);
				as= "index.jsp";
			} else {
				as="login";
			}
			return as;
		}else if(getRole()==3){
			//�������Ա�ж�

			@SuppressWarnings("static-access")
			boolean fan= loginDao.selectadmin(admin.getAname(), admin.getApwd());
			if (fan) {
				se.setAttribute("admin", admin);
				as= "index.jsp";
			} else {
				as="login";
			}
			return as;
		}  else {
			return "MyJsp";
		}
		
		
	}
	
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
