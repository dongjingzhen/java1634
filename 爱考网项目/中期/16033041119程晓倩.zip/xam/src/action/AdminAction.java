package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Class;
import po.Paper;
import po.Question;
import po.Subject;
import po.Teacher;

import com.opensymphony.xwork2.Action;

import dao.AdminDao;
import dao.HibernateSessionFactory;

public class AdminAction implements Action {
	private int seid;
	private int id;
	private Question q;
	private Paper p;
	private int jd;
	private int zd;
	AdminDao adminDao=new AdminDao();
	//��ʦ�б�����
	private List<Teacher> teacherlist;
	//�༶�б�����
	private List<Class> classlist;
	//�Ծ��б�
	private List<Paper> paperlist;
	//��⼯��
	private List<Question> qlist;
	//��Ŀ����
	private List<Subject> sublist;
	//�����ѯ��������
	private List<Object[]> alllist;
	private String choose;
	private String sub;
	
	public int getJd() {
		return jd;
	}
	public void setJd(int jd) {
		this.jd = jd;
	}
	public int getZd() {
		return zd;
	}
	public void setZd(int zd) {
		this.zd = zd;
	}
	public Paper getP() {
		return p;
	}
	public void setP(Paper p) {
		this.p = p;
	}
	public Question getQ() {
		return q;
	}
	public void setQ(Question q) {
		this.q = q;
	}
	public String getChoose() {
		return choose;
	}
	public void setChoose(String choose) {
		this.choose = choose;
	}
	public List<Object[]> getAlllist() {
		return alllist;
	}
	public void setAlllist(List<Object[]> alllist) {
		this.alllist = alllist;
	}
	public List<Subject> getSublist() {
		return sublist;
	}
	public void setSublist(List<Subject> sublist) {
		this.sublist = sublist;
	}
	public List<Question> getQlist() {
		return qlist;
	}
	public void setQlist(List<Question> qlist) {
		this.qlist = qlist;
	}

	public List<Teacher> getTeacherlist() {
		return teacherlist;
	}
	public void setTeacherlist(List<Teacher> teacherlist) {
		this.teacherlist = teacherlist;
	}
	public List<Class> getClasslist() {
		return classlist;
	}

    public void setClasslist(List<Class> classlist) {
		this.classlist = classlist;
	}

    public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getSeid() {
		return seid;
	}
	public void setSeid(int seid) {
		this.seid = seid;
	}
	public AdminDao getAdminDao() {
		return adminDao;
	}
	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}
    
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public String select(){
		String sa="";
		System.out.println(getSeid()); 
		if (getSeid()==1) {
			teacherlist=adminDao.teacherlist();
			sa="selectadmin";
		}else if (getSeid()==2) {
			classlist=adminDao.classlist();
			sa="selectclass";
		}else if (getSeid()==3) {
			//��ѯѧ���б�
		}else if (getSeid()==4) {
			//��ѯ���
			alllist=adminDao.allist();
			sa="selectquestion";
		}else if (getSeid()==5) {
			//��ѯ�Ծ�
			paperlist=adminDao.paperlist();
			sa="selectpaper";
		}
		return sa;
	}
	public String sequ(){
		if (choose.equals("GTB")) {
			qlist=adminDao.ctblist();
		}else if (choose.equals("javascript")){
			qlist=adminDao.javalist();
		}else if (choose.equals("SQLServer")){
			qlist=adminDao.sqllist();
		}
		
		return "all";
	}
	public String delete(){
		
		if (getSeid()==1) {
			adminDao.deleteteacher(getId());
		} else if(getSeid()==2) {
			adminDao.deleteclass(getId());
		}
		return "delete";
	}
	/**
	 * ��������
	 */
	public String add(){
		 
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		session.save(q);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "add";
	
	}
	/**
	 * 
	 * ������
	 */
	public String rad(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		adminDao.radm(getJd(), getZd(), p.getTitle());
		
		System.out.println(p.getTestTime());
		transaction.commit();
		//HibernateSessionFactory.closeSession();
	

		return "rad";
	}
	/**
	 * 
	 * �Ӿ��Ӳ鿴����
	 */
	public String qfp(){
		qlist=adminDao.seque(id);
		//System.out.println(qlist.get(0).getOptionA());
		return "qfp";
		
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
