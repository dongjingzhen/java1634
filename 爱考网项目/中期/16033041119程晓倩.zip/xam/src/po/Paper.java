package po;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class Paper implements java.io.Serializable {

	// Fields

	private Integer pid;
	private String subjectName;
	private String kind;
	private String title;
	private String className;
	private Timestamp testTime;
	private Integer testHour;
	private Double totalScore;
	private Integer qnumber;
	private String state;
	private Set<Question> quelist=new HashSet<Question>();
	

	// Constructors

	public Set<Question> getQuelist() {
		return quelist;
	}

	public void setQuelist(Set<Question> quelist) {
		this.quelist = quelist;
	}

	/** default constructor */
	public Paper() {
	}

	/** full constructor */
	public Paper(String subjectName, String kind, String title,
			String className, Timestamp testTime, Integer testHour,
			Double totalScore, Integer qnumber, String state) {
		this.subjectName = subjectName;
		this.kind = kind;
		this.title = title;
		this.className = className;
		this.testTime = testTime;
		this.testHour = testHour;
		this.totalScore = totalScore;
		this.qnumber = qnumber;
		this.state = state;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getSubjectName() {
		return this.subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getKind() {
		return this.kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Timestamp getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}

	public Integer getTestHour() {
		return this.testHour;
	}

	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public Double getTotalScore() {
		return this.totalScore;
	}

	public void setTotalScore(Double totalScore) {
		this.totalScore = totalScore;
	}

	public Integer getQnumber() {
		return this.qnumber;
	}

	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

}