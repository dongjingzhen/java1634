package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Admin;
import po.Paper;
import po.Question;

public class StudentDao {

	/**
	 * ��ѯ���Ե��Ծ�
	 */
	public List<Paper> paperlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Paper> paperlist = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
		
	   }
	   /**
	    * ��ѯ�Ծ��е���Ŀ
	    */
	      public List<Question> qlist(int qid){
	  		Session session = HibernateSessionFactory.getSession();
	  		Transaction transaction =session.beginTransaction();
	  	
	  		Query query=session.createQuery("from Question q where qid="+qid+"");
			List<Question> qlist =query.list();
	  		System.out.println(qlist.get(0).getOptionA());
			return qlist;
	  		
	  	   }
	      public static void main(String[] args) {
			StudentDao dao=new StudentDao();
			dao.qlist(1);
		}
	
}
