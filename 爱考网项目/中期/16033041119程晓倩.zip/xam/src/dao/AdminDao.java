package dao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Admin;
import po.All;
import po.Class;
import po.Paper;
import po.Question;
import po.Student;
import po.Subject;
import po.Teacher;
public class AdminDao {
	/**
	 * ��ѯ��ʦ�б�����
	 * 
	 */
	
	public List<Teacher> teacherlist(){
	Session session = HibernateSessionFactory.getSession();
	Transaction transaction =session.beginTransaction();
	
	List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
	transaction.commit();
	HibernateSessionFactory.closeSession();
	return teacherList;
	
   }
	/**
	 * ��ѯ����Ա�б�����
	 * 
	 */

	public List<Admin> adminlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Admin> adminList = session.createCriteria(Admin.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return adminList;
		
	   }
	/**
	 * ��ѯѧ���б�����
	 * 
	 */
	
	public List<Student> studentlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Student> studentList = session.createCriteria(Student.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return studentList;
		
	   }
	/**
	 * ��ѯ�༶�б�����
	 * 
	 */

	public List<Class> classlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Class> classList = session.createCriteria(Class.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classList;
		
	   }
	/**
	 * ��ѯ�Ծ�
	 * 
	 */
	public List<Paper> paperlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Paper> paperlist = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
		
	   }
	/**
	 * ��ѯ����б�
	 * 
	 */
	
	
	public List<Question> ctblist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
	    String	ctb="select * from question where subjectId='GTB'";
	    List<Question> ctblist =session.createSQLQuery(ctb).addEntity(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ctblist;
		
	   }
	/**
	 * 
	 * ��ѯ��Ŀ����Ŀ����
	 */
	public List<Object[]> allist(){
		HttpSession se=ServletActionContext.getRequest().getSession();
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
	    String	all="select subjectId,count(*) as co from question group by subjectId";
	    
	    List<Object[]> allist =session.createSQLQuery(all).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return allist;
	   }
	/**
	 * 
	 * ��ѯjava�����
	 */
	public List<Question> javalist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
	    String	ctb="select * from question where subjectId='javascript'";
	    List<Question> javalist =session.createSQLQuery(ctb).addEntity(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return javalist;
		
	   }
	/**
	 * 
	 *��ѯsql�����
	 */
	public List<Question> sqllist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
	    String	ctb="select * from question where subjectId='SQLServer'";
	    List<Question> sqllist =session.createSQLQuery(ctb).addEntity(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return sqllist;
		
	   }
	

	/**
	 * ɾ��teacher�б���һ�����ݵķ���
	 * 
	 */
	public void deleteteacher(int id){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Teacher teacher=(Teacher) session.get(Teacher.class, id);
		session.delete(teacher);
		transaction.commit();
		HibernateSessionFactory.closeSession();	
	}
	/**
	 * ɾ��class�б���һ�����ݵķ���
	 *
	 */
	public void deleteclass(int id){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Class clas=(Class) session.get(Class.class, id);
		session.delete(clas);
		transaction.commit();
		HibernateSessionFactory.closeSession();	
	}
	/**
	 * ����Ծ�
	 */
	public void radm(int jd,int zd,String tit){
		
         Session session = HibernateSessionFactory.getSession();
		 Transaction transaction=session.beginTransaction();
		 Paper paper = new Paper();
		 paper.setTitle(tit);
		 String sql  ="select q.* from (select top " +jd+
				"  * from question where difficulty= " +
				"'��'  order by newId() " +
				"union select top  " +zd+
				"*  from question where difficulty= " +
				"'�е�' order by newId()) as q";
	      //����obejct���� ���±�0����id��1������ѡ
	      List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
	      Set<Question> list=new HashSet<Question>();
	      list.addAll(questionList);
	      session.save(paper);
	      for (Question question : questionList) {
		  System.out.println(question);
		  paper.getQuelist().add(question);
		
	}
	      }
	   /**
	    * ��ѯ�Ծ��е���Ŀ
	    */
	      public List<Question> seque(int pid){
	  		Session session = HibernateSessionFactory.getSession();
	  		Transaction transaction =session.beginTransaction();
	  		Paper p=new Paper();
	  		p=(Paper) session.get(Paper.class, pid);
	  		Set<Question> qlist=p.getQuelist();
	  		List<Question> list=new ArrayList<Question>();
	  		list.addAll(qlist);
			return list;
	  		
	  	   }
	
	/**
	 * 
	 * ��ѯ��Ŀ
	 */
	public List<Subject> sublist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		List<Subject> sublist = session.createCriteria(Subject.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return sublist;
		
	   }
	
	
}
