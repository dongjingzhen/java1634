package com.it.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.it.po.Paper;

public class StudentDao {
	
	
	/**
	 * ��ѯ�����Ծ�
	 */
	@SuppressWarnings("unchecked")
	public List<Paper> paperlist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		List<Paper>  paperlist= session.createQuery("from Paper  where subjectName='G001'").list();
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
	}
}
