package com.it.action;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.it.dao.AdminDao;
import com.it.po.Classs;
import com.it.po.Paper;
import com.it.po.Question;
import com.it.po.Student;
import com.it.po.Teacher;
import com.opensymphony.xwork2.Action;
public class AdminAction implements Action {
	private List<Teacher> teacherlist;
	private List<Classs> classlist;
	private List<Student> studentlist;
	private List<Question> questionlist;
	private List<Paper> paperlist;
	private List<Object[]> questionobject;
	private String subjectId;
	private String chapter;
	private String questionType;
	private Question question;
	private Paper paper;
	private int pid;
	private String subjectName;
	/**
	 * ����������
	 */
	/**��Ŀ
	 */
	private String suijisubject;
	/**�༶
	 */
	private String suijiclassName;
	/**����
	 */
	private String suijititle;
	/**�ܷ�
	 */
	private Double suijitotalScore;
	/**����ʱ��
	 */
	private int suijitestHour; 
	/**��
	 */
	private int suijibriefness;
	/**����
	 */
	private int suijidifficulty;
	/**������
	 */
	private int suijiqnumber;
	/**ÿ�����
	 */
	private String suijieveryscore;
	HttpSession se=ServletActionContext.getRequest().getSession();
	AdminDao adminDao=new AdminDao();
	/**
	 * ��ѯ��ʦ
	 * @return
	 */
	public String teacher(){
		teacherlist=adminDao.teacherlist();
		return "teacherlist";
	}
	/**
	 * ��ѯ�༶
	 * @return
	 */
	@SuppressWarnings("static-access")
	public String classs(){
		classlist=adminDao.classslist();
		return "classslist";
	}
	/**
	 * ��ѯѧ��
	 * @return
	 */
	public String student(){
		studentlist=adminDao.studentlist();
		return "studentlist";
	}
	/**
	 * ��ѯ���
	 * @return
	 */
	public String question(){
		questionobject=adminDao.questionobject();
		return "questionobject";
	}
	/**
	 * ��ѯ����
	 * @return
	 */
	@SuppressWarnings("static-access")
	public String qusestionshiti(){
		String []a={getSubjectId(),getChapter(),getQuestionType()};
		se.setAttribute("a", a);
		questionlist=adminDao.questiontlist(getSubjectId(), getChapter(), getQuestionType());
		return "qusestionshitilist";
	}
	/**
	 * ��ѯ�Ծ�
	 * @return
	 */
	public String paper(){
		paperlist=adminDao.paperlist();
		return "paperlist";
		
	}
	/**
	 * �޸��Ծ�״̬
	 * @return
	 */
	public String updatepaper(){
		System.out.println(paper.getPid());
		adminDao.updatepaper(paper);
		System.out.println("555555555555");
		return "updatepaper";
		
		
	}
	/**
	 * ��������
	 * @return
	 */
	public String addshiti(){
		adminDao.addshiti(question);
		return "addshiti";
	}
	/**
	 * ������
	 * @return
	 */
	public String random(){
		questionlist=adminDao.random(getSuijisubject(), getSuijiclassName(), 
				getSuijititle(), getSuijitotalScore(),
				getSuijitestHour(), getSuijibriefness(),
				getSuijidifficulty(), getSuijiqnumber(), 
				getSuijieveryscore());
		
		return "random";
		
	}
	/**
	 * ��ѯ����������
	 * @return
	 */
	public String randomquestionlist(){
		questionlist=adminDao.getrandom(getPid());
		return "randomquestionlist";
		
		
	}
	/**
	 * ��ѯѧ���༶
	 * @return
	 */
	public String selectstudent(){
		studentlist= adminDao.studentlist();
		se.setAttribute("pid", getPid());
		se.setAttribute("subjectName", getSubjectName());
		return "selectstudent";
		
	}
	public List<Teacher> getTeacherlist() {
		return teacherlist;
	}
	public void setTeacherlist(List<Teacher> teacherlist) {
		this.teacherlist = teacherlist;
	}
	public List<Classs> getClasslist() {
		return classlist;
	}
	public void setClasslist(List<Classs> classlist) {
		this.classlist = classlist;
	}
	public List<Student> getStudentlist() {
		return studentlist;
	}
	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public List<Object[]> getQuestionobject() {
		return questionobject;
	}
	public void setQuestionobject(List<Object[]> questionobject) {
		this.questionobject = questionobject;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public HttpSession getSe() {
		return se;
	}
	public void setSe(HttpSession se) {
		this.se = se;
	}
	public String getSuijisubject() {
		return suijisubject;
	}
	public void setSuijisubject(String suijisubject) {
		this.suijisubject = suijisubject;
	}
	public Double getSuijitotalScore() {
		return suijitotalScore;
	}
	public String getSuijiclassName() {
		return suijiclassName;
	}
	public void setSuijiclassName(String suijiclassName) {
		this.suijiclassName = suijiclassName;
	}
	public void setSuijitotalScore(Double suijitotalScore) {
		this.suijitotalScore = suijitotalScore;
	}
	public String getSuijititle() {
		return suijititle;
	}
	public void setSuijititle(String suijititle) {
		this.suijititle = suijititle;
	}
	public int getSuijitestHour() {
		return suijitestHour;
	}
	public void setSuijitestHour(int suijitestHour) {
		this.suijitestHour = suijitestHour;
	}
	public int getSuijibriefness() {
		return suijibriefness;
	}
	public void setSuijibriefness(int suijibriefness) {
		this.suijibriefness = suijibriefness;
	}
	public int getSuijidifficulty() {
		return suijidifficulty;
	}
	public void setSuijidifficulty(int suijidifficulty) {
		this.suijidifficulty = suijidifficulty;
	}
	public int getSuijiqnumber() {
		return suijiqnumber;
	}
	public void setSuijiqnumber(int suijiqnumber) {
		this.suijiqnumber = suijiqnumber;
	}
	public String getSuijieveryscore() {
		return suijieveryscore;
	}
	public void setSuijieveryscore(String suijieveryscore) {
		this.suijieveryscore = suijieveryscore;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
