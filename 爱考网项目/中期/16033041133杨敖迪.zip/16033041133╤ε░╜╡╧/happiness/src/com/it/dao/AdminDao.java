package com.it.dao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.it.po.Admin;
import com.it.po.Classs;
import com.it.po.Question;
import com.it.po.Student;
import com.it.po.Teacher;
import com.it.po.Paper;
public class AdminDao {
	/**
	 * ��ѯ��ʦ�б�����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Teacher> teacherlist(){
	Session session = HibernateSessionFactory.getSession();
	Transaction transaction =session.beginTransaction();
	
	List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
	transaction.commit();
	HibernateSessionFactory.closeSession();
	return teacherList;
	
   }
	/**
	 * ��ѯ����Ա�б�����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Admin> adminlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Admin> adminList = session.createCriteria(Admin.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return adminList;
		
	   }
	/**
	 * ��ѯѧ���б�����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Student> studentlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Student> studentList = session.createCriteria(Student.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return studentList;
		
	   }
	/**
	 * ��ѯ�༶�б�����
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Classs> classslist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Classs> classsList = session.createCriteria(Classs.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classsList;
		
	   }
	/**
	 * ��ѯ����б�
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Object[]> questionobject(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		String sql="select subjectId,chapter,questionType,count(questionType) as typecount from question group by subjectId,chapter,questionType";
		List<Object[]> questionobject = session.createSQLQuery(sql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionobject;
		
	   }
	/**
	 * ��ѯ����
	 */
	
	@SuppressWarnings("unchecked")
	public static List<Question> questiontlist(String subjectId,String chapter,String questionType){
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
		Query query=session.createQuery("from Question q where q.subjectId ="+"'"+subjectId+"'"+" and q.chapter ="+"'"+chapter+"'"+" and q.questionType="+"'"+questionType+"'"+"");
		List<Question> questionlist =query.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionlist;	
	}
	/**
	 * ��ѯ�Ծ�
	 */
	@SuppressWarnings("unchecked")
	public List<Paper> paperlist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Paper> paperlist = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
	}
	/**
	 * �޸��Ծ�״̬
	 */
	public void updatepaper(Paper paper){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Paper paper2= (Paper) session.get(Paper.class, paper.getPid());
		paper2.setSubjectName(paper.getSubjectName());
		paper2.setKind(paper.getKind());
		paper2.setTitle(paper.getTitle());
		paper2.setClassName(paper.getClassName());
		paper2.setTestHour(paper.getTestHour());
		paper2.setState(paper.getState());
		session.update(paper2);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	/**
	 * ������
	 * @param suijisubject ��Ŀ
	 * @param suijiclassName �༶
	 * @param suijititle ����
	 * @param suijitotalScore �ܷ�
	 * @param suijitestHour ����ʱ��
	 * @param suijibriefness ��
	 * @param suijidifficulty ����
	 * @param suijiqnumber ������
	 * @param suijieveryscore ÿ�����
	 */
	@SuppressWarnings("unchecked")
	public List<Question> random(String suijisubject,String suijiclassName,
			String suijititle,Double suijitotalScore,
			int suijitestHour,int suijibriefness,
			int suijidifficulty,int suijiqnumber,
			String suijieveryscore){
		
        Session session = HibernateSessionFactory.getSession();
		 Transaction transaction=session.beginTransaction();
		 Paper paper = new Paper();
		 paper.setSubjectName(suijisubject);
		 paper.setClassName(suijiclassName);
		 paper.setTitle(suijititle);
		 paper.setTotalScore(suijitotalScore);
		 paper.setTestHour(suijitestHour);
		 paper.setState(suijieveryscore);
		 String sql  ="select top "+suijiqnumber+" * from (select top "+suijibriefness+" * from question q  where q.difficulty='��' order by newid() union select top "+suijidifficulty+" * from question q  where q.difficulty='����' order by newid())as qe";
		 SQLQuery query = session.createSQLQuery(sql).addEntity(Question.class);
			List<Question> questionlist = query.list();
			Set<Question> setlist = new HashSet<Question>();
			setlist.addAll(questionlist);
			paper.setQuestion(setlist);
			session.save(paper);
			transaction.commit();
			HibernateSessionFactory.closeSession();
			return questionlist;
	}
	/**
	 * ��ѯ�������
	 * @return
	 */
	public List<Question> getrandom(int pid) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper paper = new Paper();
		paper = (Paper) session.get(Paper.class, pid);
		Set<Question> quelist = paper.getQuestion();
		List<Question> questionlist = new ArrayList<Question>();
		questionlist.addAll(quelist);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionlist;
	}


	/**
	 * ��������
	 */
	public void addshiti(Question question){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		session.save(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();	
		
		
	}
	
	/**
	 * ɾ��teacher�б���һ�����ݵķ���
	 * @param id
	 */
	public void deleteteacher(int id){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Teacher teacher=(Teacher) session.get(Teacher.class, id);
		session.delete(teacher);
		transaction.commit();
		HibernateSessionFactory.closeSession();	
	}
	/**
	 * ɾ��class�б���һ�����ݵķ���
	 * @param id
	 */
	public void deleteclass(int id){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Classs clas=(Classs) session.get(Classs.class, id);
		session.delete(clas);
		transaction.commit();
		HibernateSessionFactory.closeSession();	
	}
	
	
//	public static void main(String[] args) {
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction =session.beginTransaction();
////		Criteria criteria =session.createCriteria(Paper.class)
////		                    .setFetchMode("question", FetchMode.JOIN)
////		                    .createAlias("question", "q");
////		ProjectionList projectionList= Projections.projectionList()
////		                    .add(Projections.groupProperty("subjectName"))
////		                    .add(Projections.groupProperty("q.subjectId"))
////		                    .add(Projections.groupProperty("q.questionType"))
////		                    .add(Projections.count("q.questionType"));
////		List<Object[]> objectslsit=criteria.setProjection(projectionList).list();
////		for (Object[] o : objectslsit) {
////			System.out.println(o[0]+","+o[1]+","+o[2]+","+o[5]);
////		}
//		String sql="select subjectId,chapter,questionType,count(questionType) as typecount from question group by subjectId,chapter,questionType";
//		List<Object[]> objectslsit = session.createSQLQuery(sql).list();
//		for (Object[] o : objectslsit) {
//			System.out.println(o[0]+","+o[1]+","+o[2]+","+o[3]);
//		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession();	
//		
//		
////		Paper paper1 = new Paper();
////		paper1.setSubjectName("java");
////		Paper paper2 = new Paper();
////		paper2.setSubjectName("jsp");
////		Question question1 = new Question();
////		question1.setKind("��ѡ");
////		question1.setContent("1+1��ʲô����²�����2");
////		question1.setOptionA("������ȷʱ");
////		question1.setOptionB("�������ʱ");
////		question1.setOptionC("���ۺ�ʱ");
////		question1.setOptionD("��֪��");
////		question1.setAnswer("A");
////		question1.setDifficulty("��");
////		question1.setSubjectId("CTB");
////		question1.setChapter("T01");
////		question1.setQuestionType("����");
////		
////		
////		Question question2 = new Question();
////		question2.setKind("��ѡ");
////		question2.setContent("������Լ�˧��");
////		question2.setOptionA("��˧");
////		question2.setOptionB("˧");
////		question2.setOptionC("������");
////		question2.setOptionD("̫����");
////		question2.setAnswer("A, C, D");
////		question2.setDifficulty("��");
////		question2.setSubjectId("CTB");
////		question2.setChapter("T02");
////		question2.setQuestionType("����");
////
////		session.save(paper1);
////		session.save(paper2);
////		session.save(question1);
////		session.save(question2);
////		
////		Paper paper = (Paper) session.get(Paper.class, 1);
////		paper.getQuestionset().add(question1);
////		paper.getQuestionset().add(question2);
//	}
//	
	
}
