package com.it.action;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action {
	private String subjectName;
	public String kaoshilist(){
		
		
		
		return "kaoshilist";
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
