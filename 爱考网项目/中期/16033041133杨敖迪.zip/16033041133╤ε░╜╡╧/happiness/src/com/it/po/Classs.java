package com.it.po;

import java.sql.Timestamp;


/**
 * Classs entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class Classs  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private String classNo;
     private String className;
     private String direction;
     private String headteacher;
     private String lecturer;
     private Timestamp date;
     private String state;


    // Constructors

    /** default constructor */
    public Classs() {
    }

    
    /** full constructor */
    public Classs(String classNo, String className, String direction, String headteacher, String lecturer, Timestamp date, String state) {
        this.classNo = classNo;
        this.className = className;
        this.direction = direction;
        this.headteacher = headteacher;
        this.lecturer = lecturer;
        this.date = date;
        this.state = state;
    }

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassNo() {
        return this.classNo;
    }
    
    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }

    public String getClassName() {
        return this.className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }

    public String getDirection() {
        return this.direction;
    }
    
    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getHeadteacher() {
        return this.headteacher;
    }
    
    public void setHeadteacher(String headteacher) {
        this.headteacher = headteacher;
    }

    public String getLecturer() {
        return this.lecturer;
    }
    
    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public Timestamp getDate() {
        return this.date;
    }
    
    public void setDate(Timestamp date) {
        this.date = date;
    }

    public String getState() {
        return this.state;
    }
    
    public void setState(String state) {
        this.state = state;
    }
   








}