package dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Adimin;
import po.Classes;
import po.Profession;
import po.Student;
import po.Subject;
import po.Teacher;
import po.Topic;

public class TestDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		addTopic();
	
//		String me="";
//		
//		
//		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		
//		
//		try {
//			Date dt1 = format.parse("1999-01-01 12:20:49");
//			Date dt2 = format.parse("1999-01-01 12:20:50");
//			
//			if(dt1.getTime()>dt2.getTime()){
//				
//				System.out.println("1>2");
//				me="1>2";
//				
//			}else 	if(dt1.getTime()<=dt2.getTime()-1000*60*15){
//				System.out.println(dt2.getTime());
//				System.out.println(dt1.getTime());
//				System.out.println("1<2");
//				me="1<2";
//				
//			}
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//		
//		System.out.println(me);
		
		
		
	}
	
	public static void addTopic(){
		
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
	

        Classes c1 = (Classes) session.get(Classes.class, 1);
        Classes c2 = (Classes) session.get(Classes.class, 2);
        Classes c3 = (Classes) session.get(Classes.class, 3);
        Classes c4 = (Classes) session.get(Classes.class, 4);
         

		Student student = new Student();
		student.setStudentName("右三");
		student.setIdCard("412825199901021111");
		student.setStudentNumber("S1602012");
		student.setStudentPass("666666");
		student.setClass1(c4);
		
		session.save(student);
		
     

		
		transaction.commit();
		session.close();
		
		
	}

}
