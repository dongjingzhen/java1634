package dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import po.Subject;
import po.Topic;

public class TopicDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	/**
	 * 查询所有的题目信息
	 * 
	 * @return
	 */
	public static List<Object[]> getAllTopic() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 创建查询容器，接受连接查询结果
		Criteria criteria = session.createCriteria(Topic.class)
				.setFetchMode("subject", FetchMode.JOIN)
				.createAlias("subject", "s");
		// 投影查询，科目名，试题类别，统计题数
		ProjectionList projectionList = Projections.projectionList()
				.add(Projections.groupProperty("s.subjectName"))
				.add(Projections.groupProperty("topicType"))
				.add(Projections.count("topicId"));
		// 将查询结果用object数组接收
		criteria.setProjection(projectionList);
		List<Object[]> list = criteria.list();

		// 提交事务，关闭session
		transaction.commit();
		session.close();
		// 返回查询结果
		return list;

	}

	/**
	 * 查询所有的题目分类
	 * 
	 * @return
	 */
	public List<Subject> getAllTopicType() {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 用subject类集合接受查询到的结果
		List<Subject> list = session.createCriteria(Subject.class).list();

		// 提交事务，关闭session
		transaction.commit();
		session.close();
		// 返回查询结果
		return list;

	}

	/**
	 * 查询某一类的所有题目信息
	 * 
	 * @param topic
	 * @return
	 */
	public static List<Topic> getOneTypeTopic(Topic topic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 创建hql查询语句，条件查询，去除重复
		String hql = "select distinct t from Topic t join t.subject where t.topicType=:tt and t.subject.subjectName = :ts";
		// 执行hql语句
		Query query = session.createQuery(hql);
		// 为命名参数占位符赋值
		query.setString("tt", topic.getTopicType().toString());
		query.setString("ts", topic.getSubject().getSubjectName().toString());
		// 用topic类集合接受查询结果
		List<Topic> list = query.list();

		// 提交事务，关闭session
		transaction.commit();
		session.close();
		// 返回查询结果
		return list;

	}

	/**
	 * 添加题目
	 * 
	 * @param topic
	 */
	public static void addTopic(Topic topic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 保存传回的topic对象
		session.save(topic);

		// 提交事务，关闭session
		transaction.commit();
		session.close();
	}

	/**
	 * 修改题目
	 * 
	 * @param topic
	 */
	public static void updateTopic(Topic topic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 题目与subject类关联
		topic.setSubject((Subject) session.get(Subject.class, topic
				.getSubject().getSubjectId()));
		// 更新topic对象
		session.update(topic);

		// 提交事务，关闭session
		transaction.commit();
		session.close();
	}

	/**
	 * 删除题目
	 * 
	 * @param topic
	 */
	public static void deleteTopic(Topic topic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 删除得到的topic对象
		session.delete(session.get(Topic.class, topic.getTopicId()));

		// 提交事务，关闭session
		transaction.commit();
		session.close();
	}

	public Topic getOneTopic(Topic topic) {
		// 得到session对象，开启事务
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		// 根据ID得到topic对象
		Topic topic2 = (Topic) session.get(Topic.class, topic.getTopicId());

		// 提交事务，关闭session
		transaction.commit();
		session.close();
		// 返回查询结果
		return topic2;
	}

}
