package action;

import java.util.List;

import po.ManyofTopic;
import po.Papers;

import com.opensymphony.xwork2.Action;

import dao.PapersDao;

public class PapersAction implements Action {
	// 实例化papersdao类
	PapersDao papersDao = new PapersDao();
	// 实例化manyoftopic类
	private ManyofTopic manyofTopic;
	// 实例化papers类
	private Papers papers;
	// 声明object集合
	private List<Object[]> objects;
	// 声明papers类集合
	private List<Papers> list;

	public List<Papers> getList() {
		return list;
	}

	public void setList(List<Papers> list) {
		this.list = list;
	}

	public List<Object[]> getObjects() {
		return objects;
	}

	public void setObjects(List<Object[]> objects) {
		this.objects = objects;
	}

	public Papers getPapers() {
		return papers;
	}

	public void setPapers(Papers papers) {
		this.papers = papers;
	}

	public ManyofTopic getManyofTopic() {
		return manyofTopic;
	}

	public void setManyofTopic(ManyofTopic manyofTopic) {
		this.manyofTopic = manyofTopic;
	}

	@Override
	public String execute() throws Exception {

		return null;
	}

	/**
	 * 添加试卷
	 * 
	 * @return
	 */
	public String addPapers() {
		// 调用papersdao方法并传值
		papersDao.addPapers(papers, manyofTopic);

		// 返回值
		return "addok";

	}

	/**
	 * 查询所有的试卷信息
	 * 
	 * @return
	 */
	public String getAllPapers() {
		// 调用papersdao方法并接受结果集
		list = papersDao.getAllPapers();
		// 返回值
		return "getok";
	}

	/**
	 * 查询某张试卷的题目
	 * 
	 * @return
	 */
	public String getOnePapersTopic() {
		// 调用papersdao方法传值并接受结果集
		objects = papersDao.getOnePapersTopic(papers);
		// 返回值
		return "getoneok";
	}
}
