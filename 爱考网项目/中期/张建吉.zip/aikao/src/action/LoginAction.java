package action;

import po.User;

import com.opensymphony.xwork2.Action;

public class LoginAction implements Action {
	// 角色类，接受前台传回的登陆数据，并判断用户角色
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String someOneLogin() {
		
		String message="";

		// 1学生，2老师，4管理员
		if ("1".equals(user.getRole())) {
			
			//调用查询学生dao方法

			message="1";
		}
		if ("2".equals(user.getRole())) {
			
			//调用查询教师dao方法

			message="2";
		}
		if ("4".equals(user.getRole())) {
			
			//调用查询管理员dao方法

			message="4";
		}

		return message;
	}

}
