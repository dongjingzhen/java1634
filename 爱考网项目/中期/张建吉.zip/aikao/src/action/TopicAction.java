package action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import po.Subject;
import po.Teacher;
import po.Topic;

import com.opensymphony.xwork2.Action;

import dao.TopicDao;

public class TopicAction implements Action {
	// 实例化TopicDao类
	private TopicDao topicDao = new TopicDao();
	// 实例化topic类
	private Topic topic;

	private String subjectName;

	private String topicType;
	// 声明object类集合
	private List<Object[]> list;
	// 声明subject类集合
	private List<Subject> slist;
	// 声明topic类集合
	private List<Topic> ttlist;

	public String getTopicType() {

		return topicType;
	}

	public void setTopicType(String topicType) {
		this.topicType = topicType;
	}

	public Topic getTopic() {
		return topic;
	}

	public void setTopic(Topic topic) {
		this.topic = topic;
	}

	public List<Topic> getTtlist() {
		return ttlist;
	}

	public void setTtlist(List<Topic> ttlist) {
		this.ttlist = ttlist;
	}

	public List<Subject> getSlist() {
		return slist;
	}

	public void setSlist(List<Subject> slist) {
		this.slist = slist;
	}

	public List<Object[]> getList() {
		return list;
	}

	public void setList(List<Object[]> list) {
		this.list = list;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 查询所有题目
	 * 
	 * @return
	 */
	public String getAllTopic() {

		// 调用topicdao方法接收返回值
		list = topicDao.getAllTopic();
		slist = topicDao.getAllTopicType();
		// 返回值
		return "getall";
	}

	/**
	 * 查询某个类别题目
	 * 
	 * @return
	 */
	public String getOneTypeTopic() {

		// 调用topicdao方法传值并接收返回值
		ttlist = topicDao.getOneTypeTopic(topic);
		// 检查是否乱码或查询成功
		System.out.println(topic.getSubject().getSubjectName());
		System.out.println(topic.getTopicType());
		System.out.println("显示" + topicType);
		System.out.println(ttlist.size());
		// 返回值
		return "getone";
	}

	/**
	 * 添加题目
	 * 
	 * @return
	 */
	public String addTopic() {

		// 调用topicdao方法并传值
		topicDao.addTopic(topic);

		// 返回值
		return "addok";
	}

	/**
	 * 修改题目
	 * 
	 * @return
	 */
	public String updateTopic() {
		// 调用topicdao方法并传值
		topicDao.updateTopic(topic);

		// 返回值
		return "updateok";
	}

	/**
	 * 删除题目
	 * 
	 * @return
	 */
	public String deleteTopic() {
		// 调用topicdao方法并传值
		topicDao.deleteTopic(topic);

		// 返回值
		return "deleteok";
	}

	/**
	 * 查询某个题目信息
	 * 
	 * @return
	 */
	public String getOneTopic() {
		// 调用topicdao方法传值并接收返回值
		topic = topicDao.getOneTopic(topic);

		// 返回值
		return "getoneok";
	}

}
