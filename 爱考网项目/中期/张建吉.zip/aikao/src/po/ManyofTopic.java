package po;

public class ManyofTopic {
	
	private int onejd;
	
	private int oneyb;
	
	private int onekn;
	
	private int manyjd;
	
	private int manyyb;
	
	private int manykn;

	public int getOnejd() {
		return onejd;
	}

	public void setOnejd(int onejd) {
		this.onejd = onejd;
	}

	public int getOneyb() {
		return oneyb;
	}

	public void setOneyb(int oneyb) {
		this.oneyb = oneyb;
	}

	public int getOnekn() {
		return onekn;
	}

	public void setOnekn(int onekn) {
		this.onekn = onekn;
	}

	public int getManyjd() {
		return manyjd;
	}

	public void setManyjd(int manyjd) {
		this.manyjd = manyjd;
	}

	public int getManyyb() {
		return manyyb;
	}

	public void setManyyb(int manyyb) {
		this.manyyb = manyyb;
	}

	public int getManykn() {
		return manykn;
	}

	public void setManykn(int manykn) {
		this.manykn = manykn;
	}

}
