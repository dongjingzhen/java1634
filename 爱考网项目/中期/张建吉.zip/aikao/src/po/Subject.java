package po;

import java.util.HashSet;
import java.util.Set;

/**
 * 科目信息
 * @author 19285
 *
 */
public class Subject {
	//科目id，逻辑主键，自增长
	private int subjectId;
	//科目名字，唯一，不为空
	private String subjectName;
	//科目创建人，与管理员关联，多对一	
	private Adimin adimin;
	//与题目关联，一对多
	private Set<Topic> topics = new HashSet<Topic>();
	
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public Set<Topic> getTopics() {
		return topics;
	}
	public void setTopics(Set<Topic> topics) {
		this.topics = topics;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public Adimin getAdimin() {
		return adimin;
	}
	public void setAdimin(Adimin adimin) {
		this.adimin = adimin;
	}

}
