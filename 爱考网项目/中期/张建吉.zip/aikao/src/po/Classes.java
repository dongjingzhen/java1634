package po;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * 班级信息
 * @author 19285
 *
 */
public class Classes {
	//- 班级编号
	private int classId;
	//- 班级名称
	private String className;
	//- 总人数
	private int classStudents;
	//- 开班时间
	private Date openTime;
	//与专业信息关联，多对一
	private Profession profession;
	//与教师信息关联，多对多
	private Set<Teacher> teachers = new HashSet<Teacher>();
	//与学生信息关联，一对多
	private Set<Student> students = new HashSet<Student>();
	
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public int getClassStudents() {
		return classStudents;
	}
	public void setClassStudents(int classStudents) {
		this.classStudents = classStudents;
	}
	public Date getOpenTime() {
		return openTime;
	}
	public void setOpenTime(Date openTime) {
		this.openTime = openTime;
	}
	public Profession getProfession() {
		return profession;
	}
	public void setProfession(Profession profession) {
		this.profession = profession;
	}
	public Set<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(Set<Teacher> teachers) {
		this.teachers = teachers;
	}
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}

}
