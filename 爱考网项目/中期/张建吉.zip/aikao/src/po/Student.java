package po;
/**
 * 学生信息
 * @author 19285
 *
 */
public class Student {
	
	//- 逻辑主键
	private int studentId;
	//- 学生名字
	private String studentName;
	//- 登录密码
	private String studentPass;
	//- 学生学号
	private String studentNumber;
	//- 身份证号
	private String idCard;
	//- 所属班级,多对一
	private Classes class1;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentPass() {
		return studentPass;
	}
	public void setStudentPass(String studentPass) {
		this.studentPass = studentPass;
	}
	public String getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Classes getClass1() {
		return class1;
	}
	public void setClass1(Classes class1) {
		this.class1 = class1;
	}

}
