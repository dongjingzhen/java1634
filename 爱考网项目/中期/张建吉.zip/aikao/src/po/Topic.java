package po;

import java.util.HashSet;
import java.util.Set;

/**
 * 题目信息
 * @author 19285
 *
 */
public class Topic {
	
    //试题编号 自增长  自然主键
	private int topicId;
    // 题目标题
	private String topicTitle;
    //题目正确答案
	private String topicAnswer;
    //分值
	private int topicScore;
    //难易程度
	private String topicDifficulty;
    //题目类别
	private String topicType;
    //出题人，*必填
	private String topicPeople;
	//题目所有选项
	private String topicOptionA;
	//题目所有选项
	private String topicOptionB;
	//题目所有选项
	private String topicOptionC;
	//题目所有选项
	private String topicOptionD;
    //题目类别单选或多
	private int topicSelect;
    //与科目信息关联，多对一
	private Subject subject;
	//与试卷信息关联，多对多
	private Set<Papers> papers = new HashSet<Papers>();
	
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public String getTopicTitle() {
		return topicTitle;
	}
	public void setTopicTitle(String topicTitle) {
		this.topicTitle = topicTitle;
	}
	public String getTopicAnswer() {
		return topicAnswer;
	}
	public void setTopicAnswer(String topicAnswer) {
		this.topicAnswer = topicAnswer;
	}
	public int getTopicScore() {
		return topicScore;
	}
	public void setTopicScore(int topicScore) {
		this.topicScore = topicScore;
	}
	public String getTopicDifficulty() {
		return topicDifficulty;
	}
	public void setTopicDifficulty(String topicDifficulty) {
		this.topicDifficulty = topicDifficulty;
	}
	public String getTopicType() {
		return topicType;
	}
	public void setTopicType(String topicType) {
		this.topicType = topicType;
	}
	public String getTopicPeople() {
		return topicPeople;
	}
	public void setTopicPeople(String topicPeople) {
		this.topicPeople = topicPeople;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public Set<Papers> getPapers() {
		return papers;
	}
	public void setPapers(Set<Papers> papers) {
		this.papers = papers;
	}

	public String getTopicOptionA() {
		return topicOptionA;
	}
	public void setTopicOptionA(String topicOptionA) {
		this.topicOptionA = topicOptionA;
	}
	public String getTopicOptionB() {
		return topicOptionB;
	}
	public void setTopicOptionB(String topicOptionB) {
		this.topicOptionB = topicOptionB;
	}
	public String getTopicOptionC() {
		return topicOptionC;
	}
	public void setTopicOptionC(String topicOptionC) {
		this.topicOptionC = topicOptionC;
	}
	public String getTopicOptionD() {
		return topicOptionD;
	}
	public void setTopicOptionD(String topicOptionD) {
		this.topicOptionD = topicOptionD;
	}
	public int getTopicSelect() {
		return topicSelect;
	}
	public void setTopicSelect(int topicSelect) {
		this.topicSelect = topicSelect;
	}
	

}
