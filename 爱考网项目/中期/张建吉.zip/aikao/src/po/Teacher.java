package po;

import java.util.HashSet;
import java.util.Set;

/**
 * 老师信息
 * @author 19285
 *
 */
public class Teacher {
    //教师id，逻辑主键，自增长
	private int teacherId;
	//教师编号，唯一，不为空，也是登陆账户
	private String teacherNumber;
	//教师名字，不为空
	private String teacherName;
	//登陆密码，不为空
	private String teacherPass;
	//身份证号码，唯一，不为空
	private String idCard;
	//教师类型，不为空
	private String teacherType;
	//与班级关联，多对多
	private Set<Classes> classes = new HashSet<Classes>();
	
	public Set<Classes> getClasses() {
		return classes;
	}
	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	public String getTeacherNumber() {
		return teacherNumber;
	}
	public void setTeacherNumber(String teacherNumber) {
		this.teacherNumber = teacherNumber;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getTeacherPass() {
		return teacherPass;
	}
	public void setTeacherPass(String teacherPass) {
		this.teacherPass = teacherPass;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getTeacherType() {
		return teacherType;
	}
	public void setTeacherType(String teacherType) {
		this.teacherType = teacherType;
	}
	
	
	
}
