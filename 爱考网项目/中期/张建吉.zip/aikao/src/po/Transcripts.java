package po;
/**
 * 成绩单
 * @author 19285
 *
 */
public class Transcripts {
	//成绩单编号，自然主键
	private int transcriptsId;
    //学生Id  外键
	private int studentId;
    //试卷Id  外键
	private int papersId;
    //分数score
	private int score;
    //学生答案
	private String studentAnswer;
    //试卷答案
	private String papersAnswer;
	
	public int getTranscriptsId() {
		return transcriptsId;
	}
	public void setTranscriptsId(int transcriptsId) {
		this.transcriptsId = transcriptsId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getPapersId() {
		return papersId;
	}
	public void setPapersId(int papersId) {
		this.papersId = papersId;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getStudentAnswer() {
		return studentAnswer;
	}
	public void setStudentAnswer(String studentAnswer) {
		this.studentAnswer = studentAnswer;
	}
	public String getPapersAnswer() {
		return papersAnswer;
	}
	public void setPapersAnswer(String papersAnswer) {
		this.papersAnswer = papersAnswer;
	}

	
}
