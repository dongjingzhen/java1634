package po;

import java.util.Date;
/**
 * 考试记录
 * @author 19285
 *
 */
public class Record {
    //考试编号
	private int recordId;
    //参加班级
	private String classId;
    //组织人点击开始考试的用户编号
	private String recorder;
    //试卷编号papersId
	private int papersId;
    //开始时间
	private Date startTime;
    //结束时间 
	private Date endTime;
	//考试状态
	private String papersStatus;
	
	
	public String getPapersStatus() {
		return papersStatus;
	}
	public void setPapersStatus(String papersStatus) {
		this.papersStatus = papersStatus;
	}
	public int getRecordId() {
		return recordId;
	}
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}

	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getRecorder() {
		return recorder;
	}
	public void setRecorder(String recorder) {
		this.recorder = recorder;
	}
	public int getPapersId() {
		return papersId;
	}
	public void setPapersId(int papersId) {
		this.papersId = papersId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	
	
}
