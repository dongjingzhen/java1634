package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Paper;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.PaperDao;


public class PaperAction implements Action {
	private List<Paper> plist;
	public String list(){
		PaperDao pdao =new PaperDao();
		plist=pdao.list();
		System.out.println(plist.size());
		return "paperList";
	}
	
	public String insertpaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "ipaper";
	}
	
	public String pqList(){
		
		return "paperqlist";
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Paper> getPlist() {
		return plist;
	}

	public void setPlist(List<Paper> plist) {
		this.plist = plist;
	}

}
