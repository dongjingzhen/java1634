package action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Question;
import po.Subject;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.QuestionDao;
import dao.TeacherDAO;

public class QuestionAction implements Action {
	
	private List<Question> questionList;
	private List<Subject> subList;
	private String subjectId;	
	private Question question;
	private int qid;
	public String slist()
	{
		QuestionDao qdao=new QuestionDao();
		
		subList = qdao.slist();
		System.out.println(subList.size()+"s");
		return "sList";
	}
	
	public String qlist()
	{
		QuestionDao qdao=new QuestionDao();
		questionList = qdao.qlist(subjectId);
		System.out.println(questionList.size()+"q");
		
		return "qList";
	}
	
	public String ilist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Question ques=new Question();
		
		ques.setKind(question.getKind());
		ques.setContent(question.getContent());
		ques.setOptionA(question.getOptionA());
		ques.setOptionB(question.getOptionB());
		ques.setOptionC(question.getOptionC());
		ques.setOptionD(question.getOptionD());
		ques.setAnswer(question.getAnswer());
		ques.setDifficulty(question.getDifficulty());
		ques.setSubjectId(question.getSubjectId());
		ques.setChapter(question.getChapter());
		session.save(ques);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		QuestionDao qdao=new QuestionDao();
		questionList = qdao.qlist(question.getSubjectId());
		System.out.println(questionList.size()+"q");
		return "iList";
		
	}
	public String dlist(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		System.out.println(qid);
		Question ques=(Question) session.get(Question.class,qid);
		session.delete(ques);
	
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		QuestionDao qdao=new QuestionDao();
		questionList = qdao.qlist(subjectId);
		System.out.println(questionList.size()+"q");
		return "dList";
	
		
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public List<Subject> getSubList() {
		return subList;
	}

	public void setSubList(List<Subject> subList) {
		this.subList = subList;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	

}
