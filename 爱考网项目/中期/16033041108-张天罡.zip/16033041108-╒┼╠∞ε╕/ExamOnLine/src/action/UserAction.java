package action;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionEvent;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import po.Admin;

import com.opensymphony.xwork2.Action;

import dao.LoginDao;

public class UserAction implements Action{
	private Admin user;
	private String name;
	private String pwd;
	private int role;
	

	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String login()
	{
		LoginDao dao=new LoginDao();
		boolean b=false;
		
		System.out.println(role);
		String flag="error";
		if(role==1){
			System.out.println(user.getName()+"��"+user.getPwd());
			System.out.println("1"+dao.stuLogin(user.getName(), user.getPwd()));
		
			b=dao.stuLogin(user.getName(), user.getPwd());
		}
		if(role==2){
			System.out.println(user.getName()+"��"+user.getPwd());
			System.out.println("2"+dao.teaLogin(user.getName(), user.getPwd()));
		
			b=dao.teaLogin(user.getName(), user.getPwd());
		}
		if(role==3){
			System.out.println("3"+dao.adminLogin(user.getName(), user.getPwd()));
			System.out.println(user.getName()+"��"+user.getPwd());
			b=dao.adminLogin(user.getName(), user.getPwd());

		}
		if(b){
			flag="login";
			ServletActionContext.getRequest().getSession().setAttribute("name",user.getName());
		}else{
	    flag="worry";
	    }
		
		return flag;
		
		
	}

	public Admin getUser() {
		return user;
	}

	public void setUser(Admin user) {
		this.user = user;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	

}
