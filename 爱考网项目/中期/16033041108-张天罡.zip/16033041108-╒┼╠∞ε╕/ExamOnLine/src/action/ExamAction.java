package action;

import com.opensymphony.xwork2.Action;

public class ExamAction implements Action {
	
	public String login(){
		
		return "list";
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
