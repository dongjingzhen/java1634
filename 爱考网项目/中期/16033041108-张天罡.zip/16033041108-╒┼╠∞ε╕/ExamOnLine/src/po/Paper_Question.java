package po;
// default package



/**
 * Paper_Question entity. @author MyEclipse Persistence Tools
 */

public class Paper_Question  implements java.io.Serializable {


    // Fields    

     private Integer pqid;
     private Integer pid;
     private Integer qid;


    // Constructors

    /** default constructor */
    public Paper_Question() {
    }

    
    /** full constructor */
    public Paper_Question(Integer pid, Integer qid) {
        this.pid = pid;
        this.qid = qid;
    }

   
    // Property accessors

    public Integer getPqid() {
        return this.pqid;
    }
    
    public void setPqid(Integer pqid) {
        this.pqid = pqid;
    }

    public Integer getPid() {
        return this.pid;
    }
    
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getQid() {
        return this.qid;
    }
    
    public void setQid(Integer qid) {
        this.qid = qid;
    }
   








}