package dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Question;
import po.Subject;


public class QuestionDao {
	HttpServletRequest request =ServletActionContext.getRequest();
	public List<Question> qlist(String subjectId) {
		//select stu.age , count(*) from Student stu group by stu.age
		//String hql="select q.subjectId from Question q";
		
		String hql="select q from Question q where q.subjectId = '"+subjectId+"'";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		Query query=session.createQuery(hql);
		
		
		List<Question> questionList=query.list();
		//List<Question> questionList = session.createCriteria(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionList;

	}
	public List<Subject> slist() {

		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Subject> subList = session.createCriteria(Subject.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return subList;

	}
//	public List<Question> ilist(){
//		
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction =session.beginTransaction();
//		
//		List<Question> inList = session.createCriteria(Subject.class).list();
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		return inList;
//		
//	}
}
