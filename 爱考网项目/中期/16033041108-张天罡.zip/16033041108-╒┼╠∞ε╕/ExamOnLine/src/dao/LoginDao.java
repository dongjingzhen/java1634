package dao;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSessionAttributeListener;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import po.Admin;
import po.Student;
//import po.Student;
import po.Teacher;

public class LoginDao {
	
	public Boolean adminLogin(String name,String pwd){
		boolean b=false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		//ServletActionContext.getRequest().getAttribute("name");
		Criteria criteria=session.createCriteria(Admin.class)
				.add(Restrictions.eq("name",name))
				.add(Restrictions.eq("pwd",pwd));
		List<Admin> list=criteria.list();
		if(list.size()!=0){
			b=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
		
	}
	public Boolean teaLogin(String name,String pwd){
		boolean b=false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		//ServletActionContext.getRequest().getAttribute("name");
		Criteria criteria=session.createCriteria(Teacher.class)
				.add(Restrictions.eq("tname",name))
				.add(Restrictions.eq("tpwd",pwd));
		List<Teacher> list=criteria.list();
		if(list.size()!=0){
			b=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
		
	}
	public Boolean stuLogin(String name,String pwd){
		boolean b=false;
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		//ServletActionContext.getRequest().getAttribute("name");
		Criteria criteria=session.createCriteria(Student.class)
				.add(Restrictions.eq("stuName",name))
				.add(Restrictions.eq("stuPwd",pwd));
		List<Student> list=criteria.list();
		if(list.size()!=0){
			b=true;
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return b;
		
	}
}
