package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Paper;
import po.Paper_Question;



public class PaperDao {
	public List<Paper> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Paper> teacherList = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}
	
	public List<Paper_Question> pqDao(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Paper_Question> pqList = (List<Paper_Question>) session.get(Paper_Question.class, 1);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return pqList;

	}
}
